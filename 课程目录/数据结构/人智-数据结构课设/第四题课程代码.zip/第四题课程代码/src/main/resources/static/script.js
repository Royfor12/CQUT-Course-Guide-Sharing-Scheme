// Canvas元素及其绘图上下文，用于绘制哈夫曼树
const canvas = document.getElementById('treeCanvas');
const ctx = canvas.getContext('2d');
// 当前哈夫曼树根节点
let currentTreeRoot = null;

/**
 * 调整画布大小以适应容器
 * 监听窗口尺寸变化，动态调整画布宽高
 */
function resizeCanvas() {
    const container = document.getElementById('canvas-container');
    canvas.width = container.clientWidth;
    canvas.height = container.clientHeight;
}
window.addEventListener('resize', resizeCanvas);
resizeCanvas();

/**
 * 处理输入文本并生成对应的哈夫曼编码
 * 向服务器发送请求获取哈夫曼树和编码结果，并绘制树形结构
 * @returns {Promise<void>} 异步操作完成的Promise
 */
async function processText() {
    const text = document.getElementById('sourceText').value;
    if (!text) {
        alert("Please enter some text.");
        return;
    }

    try {
        const response = await fetch('/api/huffman/process-text', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ text: text })
        });

        const data = await response.json();

        if (data.error) {
            alert(data.error);
            return;
        }

        currentTreeRoot = data.treeRoot.root;
        drawTree(currentTreeRoot);
        showEncodingResult(text, data.encodedText);

    } catch (error) {
        console.error('Error:', error);
        alert("An error occurred while processing the text.");
    }
}

/**
 * 解码二进制字符串
 * 使用源文本构建哈夫曼树来解码二进制字符串
 * @returns {Promise<void>} 异步操作完成的Promise
 */
async function decodeText() {
    const bits = document.getElementById('bitString').value;
    const sourceText = document.getElementById('sourceText').value;

    if (!bits) {
        alert("Please enter a bit string.");
        return;
    }
    try {
        const response = await fetch('/api/huffman/decode-bits', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ sourceText: sourceText, bits: bits })
        });

        const data = await response.json();

        if (data.error) {
            alert(data.error);
            return;
        }

        alert(`Decoded Text: ${data.decodedText}`);

    } catch (error) {
        console.error('Error:', error);
        alert("An error occurred while decoding.");
    }
}

/**
 * 显示编码结果在模态框中
 * 将原始文本和编码后文本展示在弹出的模态框中
 * @param {string} original - 原始文本
 * @param {string} encoded - 编码后的文本
 */
function showEncodingResult(original, encoded) {
    const modal = document.getElementById('encodingModal');
    const resultText = document.getElementById('encodingResultText');
    resultText.innerText = `${original} is encoded to ${encoded}`;
    modal.style.display = "block";
}

/**
 * 关闭编码结果显示模态框
 * 隐藏显示编码结果的弹出窗口
 */
function closeModal() {
    document.getElementById('encodingModal').style.display = "none";
}

// Tree Drawing Logic
/**
 * 绘制哈夫曼树
 * 使用Canvas API递归绘制哈夫曼树的可视化图形
 * @param {Object} root - 树的根节点对象
 */
function drawTree(root) {
    // 清除画布内容
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    if (!root) return;

    // 计算树的层级高度和节点半径
    const levelHeight = 60;
    const nodeRadius = 20;

    // 辅助函数：获取树的深度和宽度信息
    /**
     * 获取树的维度（深度和宽度）
     * 递归计算树的深度和宽度，用于确定绘制布局
     * @param {Object} node - 当前节点
     * @param {number} level - 当前层级，默认为0
     * @returns {Object} 包含深度(depth)和宽度(width)属性的对象
     */
    function getTreeDimensions(node, level = 0) {
        if (!node) return { depth: 0, width: 0 };
        if (!node.left && !node.right) return { depth: 1, width: 1 };

        const leftDim = getTreeDimensions(node.left, level + 1);
        const rightDim = getTreeDimensions(node.right, level + 1);

        return {
            depth: Math.max(leftDim.depth, rightDim.depth) + 1,
            width: leftDim.width + rightDim.width
        };
    }

    const dims = getTreeDimensions(root);

    // 如果树太大则调整画布尺寸
    const requiredWidth = dims.width * 60 + 100;
    const requiredHeight = dims.depth * levelHeight + 100;

    if (requiredWidth > canvas.width || requiredHeight > canvas.height) {
        canvas.width = Math.max(canvas.width, requiredWidth);
        canvas.height = Math.max(canvas.height, requiredHeight);
    }

    // 递归绘制树节点
    /**
     * 递归绘制树节点
     * 从根节点开始递归绘制整个哈夫曼树的节点和连接线
     * @param {Object} node - 当前要绘制的节点对象
     * @param {number} x - 当前节点的x坐标位置
     * @param {number} y - 当前节点的y坐标位置
     * @param {number} availableWidth - 当前节点可用的水平空间宽度
     */
    function drawNode(node, x, y, availableWidth) {
        if (!node) return;

        // 先绘制到子节点的连接线（确保线条在节点后面）
        const childY = y + levelHeight;

        // 根据子树宽度确定可用宽度的分配
        const offset = availableWidth / 4;

        // 绘制左子节点及连接线
        if (node.left) {
            const childX = x - offset;

            // 绘制连接线
            ctx.beginPath();
            ctx.moveTo(x, y + nodeRadius);
            ctx.lineTo(childX, childY - nodeRadius);
            ctx.strokeStyle = "#000";
            ctx.stroke();

            // 绘制边标签（0）
            ctx.fillStyle = "#000";
            ctx.font = "12px Arial";
            ctx.fillText("0", (x + childX) / 2 - 10, (y + childY) / 2);

            drawNode(node.left, childX, childY, availableWidth / 2);
        }

        // 绘制右子节点及连接线
        if (node.right) {
            const childX = x + offset;

            // 绘制连接线
            ctx.beginPath();
            ctx.moveTo(x, y + nodeRadius);
            ctx.lineTo(childX, childY - nodeRadius);
            ctx.strokeStyle = "#000";
            ctx.stroke();

            // 绘制边标签（1）
            ctx.fillStyle = "#000";
            ctx.font = "12px Arial";
            ctx.fillText("1", (x + childX) / 2 + 5, (y + childY) / 2);

            drawNode(node.right, childX, childY, availableWidth / 2);
        }

        // 绘制当前节点圆形
        ctx.beginPath();
        ctx.arc(x, y, nodeRadius, 0, 2 * Math.PI);
        ctx.fillStyle = "#fff";
        ctx.fill();
        ctx.strokeStyle = "#000";
        ctx.stroke();

        // 在节点内部绘制文字
        ctx.fillStyle = "#000";
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";

        // 如果是叶子节点，显示字符；否则显示频率
        if (!node.left && !node.right) {
             // 处理特殊字符
             let displayChar = node.symbols;
             // 注意：node.character来自JSON，可能是字符串或字符
             // 如果是控制字符，可能需要显示编码？
             // 目前假设为可打印字符
             ctx.font = "14px Arial";
             ctx.fillText(displayChar, x, y - 5);
             ctx.font = "10px Arial";
             ctx.fillText(node.frequency, x, y + 10);
        } else {
            ctx.font = "12px Arial";
            ctx.fillText(node.frequency, x, y);
        }
    }

    // 从画布中心开始绘制树
    drawNode(root, canvas.width / 2, 40, canvas.width);
}

/**
 * 上传文件并进行压缩
 * 将用户选择的文件发送到服务器进行哈夫曼压缩处理，并显示压缩结果统计
 * @returns {Promise<void>} 异步操作完成的Promise
 */
async function uploadAndCompress() {
    const fileInput = document.getElementById('fileInput');
    const file = fileInput.files[0];

    if (!file) {
        alert("Please select a file first.");
        return;
    }

    const formData = new FormData();
    formData.append('file', file);

    try {
        const response = await fetch('/api/compression/compress/file', {
            method: 'POST',
            body: formData
        });

        const data = await response.json();

        if (data.error) {
            alert("Error: " + data.error);
            return;
        }

        // 显示压缩结果统计信息
        document.getElementById('fileResult').style.display = 'block';
        document.getElementById('origSize').innerText = data.originalSize;
        document.getElementById('compSize').innerText = data.compressedSize;
        document.getElementById('compRatio').innerText = data.compressionRatio;
        document.getElementById('savedSpace').innerText = data.savedPercentage;

        // 处理下载链接
        const downloadLink = document.getElementById('downloadLink');
        if (data.downloadUrl) {
            downloadLink.href = data.downloadUrl;
            downloadLink.download = data.downloadName;
            downloadLink.style.display = 'inline-block';
            downloadLink.innerText = "Download " + data.downloadName;
        } else {
            downloadLink.style.display = 'none';
        }

    } catch (error) {
        console.error('Error:', error);
        alert("Upload failed.");
    }
}

/**
 * 上传压缩文件并进行解压
 * 将用户选择的.hz压缩文件发送到服务器进行解压处理，并提供原始文件下载
 * @returns {Promise<void>} 异步操作完成的Promise
 */
async function uploadAndDecompress() {
    const fileInput = document.getElementById('decompressFileInput');
    const file = fileInput.files[0];

    if (!file) {
        alert("Please select a .hz file first.");
        return;
    }

    const formData = new FormData();
    formData.append('file', file);

    try {
        const response = await fetch('/api/compression/decompress/file', {
            method: 'POST',
            body: formData
        });

        const data = await response.json();

        if (data.error) {
            alert("Error: " + data.error);
            return;
        }

        // 显示解压成功消息
        document.getElementById('decompressResult').style.display = 'block';
        document.getElementById('decompressMsg').innerText = "Decompression Successful!";

        // 处理解压后文件的下载链接
        const downloadLink = document.getElementById('decompressDownloadLink');
        if (data.downloadUrl) {
            downloadLink.href = data.downloadUrl;
            downloadLink.download = data.downloadName;
            downloadLink.style.display = 'inline-block';
            downloadLink.innerText = "Download " + data.downloadName;
        } else {
            downloadLink.style.display = 'none';
        }

    } catch (error) {
        console.error('Error:', error);
        alert("Decompression failed.");
    }
}