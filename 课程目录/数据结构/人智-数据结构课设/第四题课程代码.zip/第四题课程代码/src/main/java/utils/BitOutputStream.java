package utils;

import java.io.IOException;
import java.io.FileNotFoundException;
import java.lang.IllegalArgumentException;
import java.io.OutputStream;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;

/**
 * BitOutputStream允许向通用Java OutputStream写入单个位。
 * 此类能够向流写入单个位（即使必须填充一个字节直到数据
 * 刷新到底层输出流）。它也能够写入可序列化对象。
 * <p>
 * 代码基于以下参考:
 * <p>
 *     http://www.developer.nokia.com/Community/Wiki/Bit_Input/Output_Stream_utility_classes_for_efficient_data_transfer
 * <p>    
 * 原作者是Andreas Jakl。代码已被修改以支持流末尾的部分字节
 * 并允许写入可序列化对象。
 */
public class BitOutputStream {
	/**
	 * 此流写入的<code>ObjectOutputStream</code>。
	 */
	private ObjectOutputStream stream;

	/**
	 * 临时缓冲区，包含各个位，
	 * 直到字节完成并可以提交到输出流。
	 */
	private int buffer = 0;

	/**
	 * 计算填充缓冲区还剩多少位。
	 */
	private int bitCount = 8;

	/**
	 * 指示方法<code>writeBit</code>是否已被调用。
	 * 在调用<code>writeBit</code>之后不能调用方法<code>writeObject</code>。
	 */
	private boolean writeBitCalled = false;

	/**
	 * 创建一个向指定<code>OutputStream</code>写入位的<code>BitOutputStream</code>。
	 * @param out 要写入的输出流
	 * @throws IOException - 如果写入流头时发生I/O错误 
     * @throws SecurityException - 如果不受信任的子类非法覆盖安全敏感方法 
     * @throws NullPointerException - 如果<code>out</code>为<code>null</code>
	 */
	public BitOutputStream(OutputStream out) throws IOException {
		stream = new ObjectOutputStream(out);
	}

	/**
	 * 创建一个向给定名称的文件写入位的<code>BitOutputStream</code>流。
	 * @param name 要写入位的文件名
	 * @throws FileNotFoundException 如果文件不存在，是目录而不是常规文件，
	 *         或由于其他原因无法打开进行读取
	 */
	public BitOutputStream(String name) throws IOException {
		stream = new ObjectOutputStream(new FileOutputStream(name));
	}

	/**
	 * 向流写入单个位。只有当字节完成时（或当此流关闭时）
	 * 才会刷新到底层<code>OutputStream</code>。
	 * @param bit 要写入的下一个位（1或0）
	 * @throws IllegalArgumentException 如果要写入的位不是整数1或0
	 */
	synchronized public void writeBit(int bit) throws IOException {
		// 检查流是否处于可写状态
		if (stream == null) {
			throw new IOException("the stream is not open for writing");
		}

		// 验证输入位是否为有效的二进制位（0或1）
		if (bit != 0 && bit != 1) {
			throw new IOException(bit + " is not a bit; did you use chars '0', '1'? use ints 0, 1");
		}

		// 标记已经调用过writeBit方法，这将影响后续对writeObject的调用
		writeBitCalled = true;

		// 将新位添加到缓冲区的最低位
		buffer = (buffer << 1) | bit;
		// 减少缓冲区中剩余的位数计数
		bitCount--;

		// 如果缓冲区已满（达到8位），则刷新到输出流
		if (bitCount == 0) {
			flush();
		}
	}

	/**
	 * 向此流写入一个对象。
	 * @throws IOException 如果发生I/O错误
	 */
	synchronized public void writeObject(Object obj) throws IOException
	{
		// 检查流是否处于可写状态
		if (stream == null) {
			throw new IOException("the stream is not open for writing");
		}
		// 检查是否已经调用了writeBit方法，因为两者不能混合使用
		else if (writeBitCalled) {
			throw new IOException("cannot call writeObject after a call to writeBit");
		}

		// 将对象写入输出流
		stream.writeObject(obj);
	}

	/**
	 * 将当前缓存写入此流并重置缓冲区。
	 * @throws IOException 如果发生I/O错误
	 */
	private void flush() throws IOException {
		// 当缓冲区已满（包含8位）时，将缓冲区内容写入输出流
		if (bitCount == 0) {
			// 将缓冲区的字节内容写入输出流
			stream.write((byte) buffer);
			// 重置位计数器，准备接收新的8位
			bitCount = 8;
			// 清空缓冲区，准备接收新的位
			buffer = 0;
		}
	}

	/**
	 * 刷新数据并关闭底层输出流。
	 * @throws IOException 如果发生I/O错误
	 */
	public void close() throws IOException
	{
		// 如果已经调用了writeBit方法，需要处理缓冲区中剩余的位
		if (writeBitCalled) {
			// 如果缓冲区中有未写入的位（非完整的字节）
			if (bitCount != 8) {
				// 将剩余的位写入输出流，这些位会被左对齐到字节边界
				stream.write((byte) buffer);
			}
			else {
				// 如果没有写入任何位，将bitCount设置为0，表示没有剩余位
				bitCount = 0;
			}

			// 写入最后保存的位数信息，以便在读取时知道如何处理最后的字节
			// 这个值表示最后字节中实际包含的位数
			stream.write((byte) (8 - bitCount));
		}

		// 关闭底层输出流并清理引用
		stream.close();
		stream = null;
	}
}