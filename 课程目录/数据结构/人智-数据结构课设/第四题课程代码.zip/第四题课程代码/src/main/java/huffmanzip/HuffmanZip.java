package huffmanzip;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.TreeMap;

import huffman.HuffmanTree;
import utils.BitInputStream;
import utils.BitOutputStream;

/**
 * 核心功能：提供基于哈夫曼编码算法的文本文件压缩与解压缩能力，
 * 压缩后生成后缀为 ".hz" 的二进制压缩文件，解压缩时仅支持该格式的压缩文件，
 * 全程依赖自定义的 {@link huffman.HuffmanTree} 构建哈夫曼树，
 * 以及 {@link utils.BitInputStream}、{link utils.BitOutputStream} 处理位级别的读写（突破字节最小单位限制，提升压缩效率）。
 *
 * 设计思路：
 * 1.  压缩时：先统计文件字符频率 → 构建哈夫曼树 → 生成字符对应的哈夫曼编码 → 写入频率表（用于解压缩重建哈夫曼树）→ 写入哈夫曼编码流
 * 2.  解压缩时：读取频率表 → 重建哈夫曼树 → 解析位流编码 → 还原为原始文本文件
 *
 * 注意事项：
 * 1.  仅支持文本文件的压缩与解压缩，不支持二进制文件（如图片、音频等）
 * 2.  压缩后的文件后缀固定为 ".hz"，解压缩仅识别该后缀文件
 * 3.  解压缩时，若目标还原文件已存在，会自动删除原有文件并覆盖
 */
public class HuffmanZip {
    /**
     * 从指定文本文件中读取所有字符，构建并返回字符-频率映射表
     * <p>
     * 核心作用：统计每个字符在文件中出现的次数，为后续构建哈夫曼树提供数据支撑，
     * 采用 TreeMap 存储，可保证字符的有序性（便于后续哈夫曼树的构建与还原一致性）。
     * </p>
     * @param fileName 待统计的文本文件路径（绝对路径或相对路径均可）
     * @return TreeMap<Character, Integer> 键：文件中出现的字符；值：该字符出现的总次数（频率）
     * @throws IOException 当文件不存在、文件不可读或读取过程中发生 IO 异常时抛出
     */
    private static TreeMap<Character, Integer> buildFrequencies (String fileName) throws IOException {
        // 初始化 TreeMap，用于存储字符-频率映射，默认按字符 Unicode 编码排序
        TreeMap<Character, Integer> frequencies = new TreeMap<> ();

// 1.创建 FileReader 字符输入流，用于读取文本文件中的字符
        FileReader reader = new FileReader (fileName);

// 2.读取单个字符（返回值为 int 类型，存储的是字符的 Unicode 编码，-1 表示读取到文件末尾）
        int curChar = reader.read();

        // 循环读取文件，直到读取到文件末尾（curChar == -1）
        while (curChar != -1) {
//2-1 将 int 转换为对应的 char 类型字符
            char character = (char) curChar;

            // 2-2更新字符频率：若字符已存在，频率+1；若不存在，默认频率为 0 再+1
            frequencies.put(character, frequencies.getOrDefault(character, 0) + 1);

            // 读取下一个字符，准备进入下一次循环判断
            curChar = reader.read();
        }

// 关闭字符输入流，释放文件资源（避免资源泄露）
        reader.close();

//3. 返回构建完成的字符-频率映射表
//{a=2, b=1, c=1}
        return frequencies;
    }





    /**
     * 压缩流程详情：
     * 1.  调用 buildFrequencies 方法统计目标文件的字符频率
     * 2.  基于字符频率表构建哈夫曼树
     * 3.  创建 ".hz" 后缀的压缩文件，并用 BitOutputStream 包装以支持位级写入
     * 4.  将字符频率表写入压缩文件（供解压缩时重建哈夫曼树使用）
     * 5.  再次读取原始文本文件，将每个字符转换为对应的哈夫曼编码，写入压缩文件
     * 6.  关闭所有流资源，完成压缩
     */
    public static void encode(String fileName) throws IOException {
// 步骤1：构建字符频率表
        TreeMap<Character, Integer> frequencies = buildFrequencies(fileName);

// 步骤2：基于字符频率表构建哈夫曼树，用于生成字符的哈夫曼编码
        HuffmanTree hTree = new HuffmanTree (frequencies);

        // ：定义压缩文件路径，在原始文件名称后添加 ".hz" 后缀
        String binaryFile = fileName + ".hz";

        // 2-0步骤4：创建 BitOutputStream 位输出流，用于向压缩文件写入位数据和序列化对象
        BitOutputStream bitOutputStream = new BitOutputStream(binaryFile);

//2-1 将字符频率表序列化写入压缩文件（解压缩时需通过该表重建相同的哈夫曼树）
        bitOutputStream.writeObject(frequencies);

// 3创建 FileReader 字符输入流，再次读取原始文件，用于转换哈夫曼编码
        FileReader reader = new FileReader (fileName);

//3.1 读取原始文件的第一个字符
        int curChar = reader.read();

        // 循环读取原始文件的所有字符，直到文件末尾
        while (curChar != -1) {
            // 将 int 类型的 Unicode 编码转换为对应的 char 类型字符
            char character = (char) curChar;
            try {
// 核心：通过哈夫曼树获取当前字符对应的哈夫曼编码，并写入压缩文件的位流中
                hTree.writeCode(character, bitOutputStream);
            } catch (Exception e) {
                // 捕获哈夫曼编码写入过程中的异常，包装为 IO 异常并抛出（统一异常类型，便于调用方处理）
                throw new IOException("Error writing code for character: " + character, e);
            }
            // 读取下一个字符，进入下一次循环
            curChar = reader.read();
        }
        // 步骤6：关闭所有流资源，释放文件句柄（先关闭输入流，再关闭输出流）
        reader.close();
        bitOutputStream.close();
    }


    /**
     * 对哈夫曼压缩生成的 ".hz" 文件进行解压缩，还原为原始文本文件
     * <p>
     * 解压缩流程详情：
     * 1.  校验输入文件是否为 ".hz" 后缀，非该格式直接终止解压缩
     * 2.  定义还原文件路径（去除 ".hz" 后缀，与原始文件名称一致）
     * 3.  若还原文件已存在，自动删除原有文件（避免文件覆盖冲突）
     * 4.  用 BitInputStream 包装压缩文件，读取字符频率表
     * 5.  基于频率表重建哈夫曼树（与压缩时的哈夫曼树完全一致）
     * 6.  计算需要还原的总字符数（避免读取压缩时填充的无效位）
     * 7.  循环解析位流编码，还原每个字符并写入还原文件
     * 8.  关闭所有流资源，完成解压缩
     * </p>
     * @param fileName 要进行解压缩的 ".hz" 格式压缩文件路径
     * @throws IOException 当压缩文件不存在、不可读、还原文件无法创建/写入，或读写过程中发生 IO 异常时抛出
     * @throws ClassNotFoundException 当读取压缩文件中的频率表时，无法反序列化（类加载失败）时抛出（如 HuffmanTree 类结构变更）
     */
    public static void decode(String fileName) throws IOException, ClassNotFoundException {
        // 校验输入文件是否为 ".hz" 后缀，非该格式直接打印错误信息并返回
        if (!fileName.endsWith(".hz"))
        {
            System.err.println("Error: not a .hz file. The program aborts!");
            return;
        }

        // 定义还原文件路径，去除压缩文件的 ".hz" 后缀
        String decodedFile = fileName.replace(".hz", "");
        // 封装还原文件为 File 对象，便于后续判断文件是否存在
        File outputFile = new File (decodedFile);

        // 若还原文件已存在，自动删除原有文件（适用于微服务等无需人工交互的场景）
        if (outputFile.exists()) {
            outputFile.delete();
        }

        // 步骤4：创建 BitInputStream 位输入流，用于读取压缩文件中的位数据和序列化对象
        BitInputStream bitInputStream = new BitInputStream(fileName);

//1. 读取压缩文件中存储的字符频率表（反序列化），抑制未检查转换的警告（明确为 TreeMap 类型，安全转换）
        @SuppressWarnings("unchecked")
        TreeMap<Character, Integer> frequencies = (TreeMap<Character, Integer>) bitInputStream.readObject();
// 2.基于读取到的频率表，重建与压缩时完全一致的哈夫曼树（解码的核心依据）
        HuffmanTree hTree = new HuffmanTree(frequencies);

// 步骤6：创建 FileWriter 字符输出流，用于将还原后的字符写入原始文件
        FileWriter writer = new FileWriter(decodedFile);

        // 计算需要还原的总字符数（所有字符的频率之和）
        // 核心作用：哈夫曼编码压缩时，为了满足字节对齐，可能会填充无效位，
        // 通过总字符数控制解码循环次数，避免读取到填充的无效位导致解码错误
        long totalChars = 0;
        for (int freq : frequencies.values()) {
            totalChars += freq;
        }

// 步骤7：循环解码，还原每个字符并写入还原文件，直到还原完所有字符
        for (long i = 0; i < totalChars; i++) {
            try {
// 核心：通过哈夫曼树解析位流中的编码，还原为对应的原始字符
                char curChar = hTree.readCode(bitInputStream);
                // 将还原后的字符写入还原文件
                writer.write(curChar);
            } catch (Exception e) {
                throw new IOException("Error reading code from input stream", e);// 捕获哈夫曼编码解析过程中的异常，包装为 IO 异常并抛出
            }
        }
        // 步骤8：关闭所有流资源，释放文件句柄（先关闭输出流，再关闭输入流）
        writer.close();
        bitInputStream.close();
    }
}