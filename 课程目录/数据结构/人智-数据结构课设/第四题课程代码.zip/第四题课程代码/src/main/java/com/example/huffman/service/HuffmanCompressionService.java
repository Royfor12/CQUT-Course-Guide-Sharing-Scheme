package com.example.huffman.service;

import huffmanzip.HuffmanZip;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * 核心功能：提供文件压缩、解压缩、批量压缩、上传文件处理、测试文件查询等业务功能
 */
@Service
public class HuffmanCompressionService {
    /**
     * 压缩指定路径的文件
     * @param inputFilePath 输入文件的完整路径（例如：D:/test/text.txt）
     * @return boolean - 压缩是否成功（true=成功，false=失败）
     */
    public boolean compressFile(String inputFilePath) throws IOException {
        try {
            // 构建压缩后的文件路径（原始路径 + .hz 后缀，作为霍夫曼压缩文件标识）
            String compressedFilePath = inputFilePath + ".hz";

            // 调用霍夫曼压缩工具类，执行文件编码（压缩）操作
            HuffmanZip.encode(inputFilePath);

            // 检查压缩后的文件是否成功创建
            File compressedFile = new File(compressedFilePath);
            return compressedFile.exists();
        } catch (Exception e) {
            // 捕获异常并包装为 IOException，向上抛出并携带错误信息
            throw new IOException("Error during compression: " + e.getMessage(), e);
        }
    }




    /**
     * 解压缩指定路径的.hz霍夫曼压缩文件
     *
     * @param compressedFilePath 压缩文件的完整路径（例如：D:/test/text.txt.hz）
     * @return boolean - 解压缩是否成功（true=成功，false=失败）
     * @throws IOException 当压缩文件无效、没有读写权限或解压缩逻辑出错时抛出
     * @throws ClassNotFoundException 当霍夫曼工具类解码时，找不到依赖的类时抛出
     */
    public boolean decompressFile(String compressedFilePath) throws IOException, ClassNotFoundException {
        try {
            // 校验文件路径是否以.hz结尾，若不是则自动补充.hz后缀
            if (!compressedFilePath.endsWith(".hz")) {
                compressedFilePath += ".hz";
            }

            // 构建解压缩后的文件路径（去除.hz后缀，还原原始文件名）
            String decompressedFilePath = compressedFilePath.replace(".hz", "");



            // 调用霍夫曼压缩工具类，执行文件解码（解压缩）操作
            HuffmanZip.decode(compressedFilePath);



            // 检查解压缩后的原始文件是否成功创建
            File decompressedFile = new File(decompressedFilePath);
            return decompressedFile.exists();
        } catch (Exception e) {
            // 捕获异常并包装为 IOException，向上抛出并携带错误信息
            throw new IOException("Error during decompression: " + e.getMessage(), e);
        }
    }




    /**
     * 压缩文本文件并返回详细的压缩结果信息
     *
     * @param inputFilePath 输入文本文件的完整路径
     * @return CompressionResult - 封装了压缩详情的结果对象
     * @throws IOException 当文件不存在或压缩失败时抛出
     * @throws ClassNotFoundException 当解压缩校验时找不到依赖类时抛出
     */
    public CompressionResult compressTextFile(String inputFilePath) throws IOException, ClassNotFoundException {
        // 根据文件路径创建文件对象
        File inputFile = new File(inputFilePath);
        // 校验原始文件是否存在
        if (!inputFile.exists()) {
            throw new IOException("Input file does not exist: " + inputFilePath);
        }

        // 获取原始文件的大小（单位：字节）
        long originalSize = inputFile.length();

        // 执行文件压缩操作，获取压缩是否成功的标识
        boolean compressSuccess = compressFile(inputFilePath);

        // 若压缩失败，抛出异常
        if (!compressSuccess) {
            throw new IOException("Compression failed for: " + inputFilePath);
        }

        // 构建压缩文件路径，获取压缩后文件的大小
        String compressedFilePath = inputFilePath + ".hz";
        File compressedFile = new File(compressedFilePath);
        long compressedSize = compressedFile.length();

        // 计算压缩比率（压缩后大小 / 原始大小）
        double compressionRatio = (double) compressedSize / originalSize;
        // 计算空间节省百分比（(原始大小 - 压缩后大小) / 原始大小 * 100%）
        double savedPercentage = (1 - compressionRatio) * 100;

        // 解压缩文件，校验压缩文件的完整性（确保压缩后的文件能正常解压缩）
        boolean decompressSuccess = decompressFile(compressedFilePath);

        // 若解压缩校验失败，抛出异常
        if (!decompressSuccess) {
            throw new IOException("Decompression failed for: " + compressedFilePath);
        }

        // 创建并返回压缩结果对象
        return new CompressionResult(
                inputFilePath,
                originalSize,
                compressedSize,
                compressionRatio,
                savedPercentage,
                true
        );
    }



    /**
     * 处理前端上传的普通文件，      执行压缩操作并返回压缩结果
     *
     * @param file 前端上传的文件（Spring 封装为 MultipartFile 类型）
     * @return Map<String, Object> - 包含压缩结果和下载信息的Map对象
     * @throws IOException 当文件写入失败或压缩失败时抛出
     */
    public Map<String, Object> handleUploadedFile(MultipartFile file) throws IOException {
        // 创建Map对象，用于返回前端的响应数据
        Map<String, Object> response = new HashMap<>();

        // 获取上传文件的原始文件名
        String originalFileName = file.getOriginalFilename();
        // 创建临时目录（前缀为huffman_upload_，用于存放上传的临时文件）
        Path tempDir = Files.createTempDirectory("huffman_upload_");
        // 构建临时文件的路径（临时目录 + 原始文件名）
        Path tempFile = tempDir.resolve(originalFileName);

        // 将上传文件的字节数据写入临时文件（落地到本地磁盘，方便后续压缩）
        Files.write(tempFile, file.getBytes());

        // 声明压缩结果对象
        CompressionResult result = null;
        try {
            // 压缩临时文件，获取详细压缩结果
            result = compressTextFile(tempFile.toString());
        } catch (ClassNotFoundException e) {
            // 捕获类未找到异常，包装为IOException并向上抛出
            throw new IOException("Class not found during compression: " + e.getMessage(), e);
        }

        // 生成唯一文件ID（用于后续下载压缩文件）
        String fileId = UUID.randomUUID().toString();
        // 构建压缩文件的路径
        Path compressedFilePath = Paths.get(tempFile.toString() + ".hz");

        // 封装响应数据，返回给前端
        response.put("fileName", originalFileName);
        response.put("originalSize", result.getOriginalSize());
        response.put("compressedSize", result.getCompressedSize());
        response.put("compressionRatio", String.format("%.2f%%", result.getCompressionRatio() * 100));
        response.put("savedPercentage", String.format("%.2f%%", result.getSavedPercentage()));
        response.put("fileId", fileId);
        response.put("compressedFilePath", compressedFilePath.toString());

        return response;
    }






    /**
     * 处理前端上传的.hz压缩文件，    执行解压缩操作并返回解压缩结果
     *
     * @param file 前端上传的.hz霍夫曼压缩文件
     * @return Map<String, Object> - 包含解压缩结果和下载信息的Map对象
     * @throws IOException 当文件格式无效、写入失败或解压缩失败时抛出
     * @throws ClassNotFoundException 当解压缩时找不到依赖类时抛出
     */
    public Map<String, Object> handleUploadedCompressedFile(MultipartFile file) throws IOException, ClassNotFoundException {
        // 创建Map对象，用于返回前端的响应数据
        Map<String, Object> response = new HashMap<>();

        // 获取上传文件的原始文件名
        String fileName = file.getOriginalFilename();
        // 校验文件格式是否为.hz后缀，若不是则抛出异常
        if (fileName == null || !fileName.endsWith(".hz")) {
            throw new IOException("Invalid file format! Please upload a .hz Huffman compressed file.");
        }

        // 创建临时目录（前缀为huffman_decompress_，用于存放上传的压缩文件和解压缩后的文件）
        Path tempDir = Files.createTempDirectory("huffman_decompress_");
        // 构建压缩文件的临时路径
        Path tempFile = tempDir.resolve(fileName);
        // 将上传的压缩文件写入临时路径
        Files.write(tempFile, file.getBytes());

        // 执行解压缩操作，获取解压缩是否成功的标识
        boolean success = decompressFile(tempFile.toString());

        // 若解压缩失败，抛出异常
        if (!success) {
            throw new IOException("File decompression failed!");
        }

        // 构建原始文件名（去除.hz后缀）
        String originalFileName = fileName.substring(0, fileName.length() - 3);
        // 构建解压缩后的文件路径
        Path decompressedFilePath = tempDir.resolve(originalFileName);

        // 生成唯一文件ID（用于后续下载解压缩后的文件）
        String fileId = UUID.randomUUID().toString();

        // 封装响应数据，返回给前端
        response.put("fileName", originalFileName);
        response.put("fileId", fileId);
        response.put("decompressedFilePath", decompressedFilePath.toString());
        response.put("success", true);

        return response;
    }

    /**
     * 压缩结果封装类（静态内部类）
     * 作用：专门用于封装单个文件的压缩详情，统一返回压缩相关信息，方便调用者使用
     * 注解说明：
     * 1. @Getter - 自动为所有私有属性生成 Getter 方法（无需手写 getFileName()、getOriginalSize() 等）
     *    特别说明：boolean 类型属性（success）会自动生成 isSuccess() 方法
     * 2. @AllArgsConstructor - 自动生成包含所有成员变量的全参数构造方法（无需手写6个参数的构造器）
     */
    @Getter
    @AllArgsConstructor
    public static class CompressionResult {
        private String fileName;      // 文件名（完整路径）
        private long originalSize;    // 原始文件大小（单位：字节）
        private long compressedSize;  // 压缩后文件大小（单位：字节）
        private double compressionRatio; // 压缩比率（压缩后大小 / 原始大小）
        private double savedPercentage;  // 空间节省百分比（(原始大小-压缩后大小)/原始大小 * 100%）
        private boolean success;      // 压缩是否成功（true=成功，false=失败）
    }
}