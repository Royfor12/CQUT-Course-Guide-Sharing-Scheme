package com.example.huffman.service;

import huffman.HuffmanTree;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

/**
 * 霍夫曼处理服务类
 * 注解说明：@Service 表示这个类是Spring框架的「服务层组件」，用于封装业务逻辑（这里是霍夫曼编码/解码逻辑）
 * 核心功能：提供 文本转霍夫曼编码（加密/压缩基础）、霍夫曼二进制位串转原始文本（解码）的功能
 */
@Service
public class HuffmanProcessingService {

    /**
     * 核心方法：对输入的文本进行处理，生成完整的霍夫曼编码结果
     * 简单理解：把普通文字，转换成霍夫曼算法对应的二进制编码串，同时返回字符出现频率等信息
     *
     * @param text 待处理的原始文本（比如"abc123"这种普通字符串）
     * @return Map<String, Object> 封装了所有处理结果的集合（键值对形式，方便获取对应信息）
     *         包含的关键信息：
     *         1. error：当文本为空时，返回的错误提示
     *         2. treeRoot：构建好的霍夫曼树（后续解码需要用到）
     *         3. codes：编码标识（当前实现暂返回"N/A"）
     *         4. encodedText：最终生成的霍夫曼二进制编码串（核心结果）
     *         5. frequencies：每个字符在文本中出现的次数（频率）
     */
    public Map<String, Object> processText(String text) {
        // 创建一个HashMap集合，用于存放最终的处理结果（键是字符串，值是任意类型数据）
        Map<String, Object> result = new HashMap<>();

        // 1. 非空校验：先判断输入的文本是不是null（空对象）或者空字符串（""）
        if (text == null || text.isEmpty()) {
            // 如果文本为空，往结果集合中存入错误提示信息
            result.put("error", "Text cannot be empty");
            return result;
        }

        // 2. 计算文本中每个字符出现的频率（次数）
        // TreeMap会自动对字符（键）进行排序，方便后续构建霍夫曼树
        TreeMap<Character, Integer> frequencies = calculateFrequencies(text);

        // 3. 根据字符频率，构建一棵霍夫曼树（霍夫曼编码/解码的核心依赖）
        HuffmanTree tree = new HuffmanTree(frequencies);

        // 4. 生成霍夫曼编码文本：把原始文本的每个字符，逐个转换成对应的霍夫曼编码，再拼接成完整字符串
        // StringBuilder：高效拼接字符串的工具（比直接用String拼接性能更好，尤其文本较长时）
        StringBuilder encoded = new StringBuilder();
        // 遍历原始文本的每一个字符
        for (char c : text.toCharArray()) {
            // 调用霍夫曼树的encode方法，将单个字符转换成对应的二进制编码
            // 并把编码拼接到StringBuilder中
            encoded.append(tree.encode(c));
        }

        // 5. 把所有处理结果存入Map集合，方便调用者获取
        result.put("treeRoot", tree); // 存入构建好的霍夫曼树
        result.put("codes", "N/A for this implementation"); // 编码标识（当前实现暂不返回具体编码映射）
        result.put("encodedText", encoded.toString()); // 存入最终的霍夫曼编码串（转换为普通字符串格式）
        result.put("frequencies", frequencies); // 存入字符频率表

        // 返回包含所有结果的Map集合
        return result;
    }

    /**
     * 私有辅助方法：计算原始文本中每个字符出现的频率（次数）
     * 私有方法说明：只能在当前类内部被调用，外部无法直接使用，用于封装重复逻辑
     *
     * @param text 输入的原始文本
     * @return TreeMap<Character, Integer> 字符频率映射表（键：字符；值：该字符出现的次数）
     *         TreeMap特性：会按照字符的ASCII码顺序自动排序，方便后续处理
     */
    private TreeMap<Character, Integer> calculateFrequencies(String text) {
        // 创建TreeMap对象，用于存放字符和对应的出现次数
        TreeMap<Character, Integer> frequencies = new TreeMap<>();

        // 遍历原始文本中的每一个字符
        for (char c : text.toCharArray()) {
            // 统计字符出现次数：
            // getOrDefault(c, 0)：如果Map中已经有该字符，就获取它的当前次数；如果没有，就默认返回0
            // 然后给次数加1，再存回Map中
            frequencies.put(c, frequencies.getOrDefault(c, 0) + 1);
        }

        // 返回统计好的字符频率表
        return frequencies;
    }

    /**
     * 核心方法：将霍夫曼编码的二进制位串，解码转换为原始文本
     * 简单理解：把编码后的二进制字符串（比如"0100110"），还原成最初的普通文字
     *
     * @param sourceText 源文本（用于构建霍夫曼树的字符频率表，如果该参数有效，就用它统计频率）
     * @param bits 待解码的霍夫曼二进制位串（就是processText方法生成的encodedText）
     * @return Map<String, Object> 包含解码结果的集合
     *         关键信息：decodedText - 解码后的原始文本（核心结果）
     */
    public Map<String, Object> decodeBits(String sourceText, String bits) {
        // 创建HashMap集合，用于存放解码结果
        Map<String, Object> result = new HashMap<>();

        // 声明一个TreeMap变量，用于存放字符频率表（后续构建霍夫曼树用）
        TreeMap<Character, Integer> frequencies = null;

        // 1. 判断源文本是否有效（非null且非空）
        if (sourceText != null && !sourceText.isEmpty()) {
            // 如果源文本有效，就调用统计方法，生成字符频率表
            frequencies = calculateFrequencies(sourceText);
        }

        // 2. 根据获取到的频率表，构建霍夫曼树（解码的核心依赖，必须和编码时的树一致才能正确解码）
        HuffmanTree tree = new HuffmanTree(frequencies);

        // 3. 调用霍夫曼树的解码方法，将二进制位串转换为原始文本
        String decodedText = tree.decodeText(bits);

        // 4. 把解码后的文本存入结果集合
        result.put("decodedText", decodedText);

        // 返回包含解码结果的Map集合
        return result;
    }
}