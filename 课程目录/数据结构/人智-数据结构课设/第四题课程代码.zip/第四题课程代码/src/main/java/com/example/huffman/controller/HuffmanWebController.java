package com.example.huffman.controller;

import com.example.huffman.service.HuffmanProcessingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * 霍夫曼编码Web控制器
 * 提供文本处理和比特解码的REST API接口
 */
@RestController
@RequestMapping("/api/huffman")
@CrossOrigin(origins = "*")
public class HuffmanWebController {

    @Autowired
    private HuffmanProcessingService processingService; // 注入霍夫曼处理服务

    /**
     * 处理文本并生成霍夫曼编码
     * @param request 包含待处理文本的请求参数，键为"text"
     * @return 包含处理结果的Map对象，包含编码、频率统计等信息
     */
    @PostMapping("/process-text")
    public Map<String, Object> processText(@RequestBody Map<String, String> request) {
        String text = request.get("text");
        return processingService.processText(text);
    }

    /**
     * 解码比特串
     * @param request 包含源文本和比特串的请求参数，键分别为"sourceText"和"bits"
     * @return 包含解码结果的Map对象
     */
    @PostMapping("/decode-bits")
    public Map<String, Object> decodeBits(@RequestBody Map<String, String> request) {
        String text = request.get("sourceText");
        String bits = request.get("bits");
        return processingService.decodeBits(text, bits);
    }
}
