package huffman;

import java.io.IOException;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.TreeMap;
import utils.*;
import lombok.Getter;

/**
 * 表示用于根据给定数据集中字符频率进行编码和解码的霍夫曼树。
 * 
 * <p>
 * 树是根据字符频率映射构建的。叶节点存储单个字符，而内部节点表示其子节点的合并频率。
 * 编码和解码操作既支持迭代方式也支持递归方式。
 * </p>
 */
@Getter
public class HuffmanTree {
    
	/** 霍夫曼树的根节点 */
    private HNode root;

    /**
     * 根据字符频率构建霍夫曼树。
     *
     * @param frequencies 字符到对应频率的映射
     */
    public HuffmanTree (TreeMap<Character, Integer> frequencies) {
        // 1. 初始化优先队列（绑定HNodeComparator）
		PriorityQueue<HNode> pQueue = new PriorityQueue<> (new HNodeComparator());
        // 2. 遍历字符-频率映射表，为每个字符创建对应的哈夫曼叶子节点，并加入优先队列
        // 传入自定义的HNodeComparator比较器，用于定义优先队列中哈夫曼节点的排序规则（按频率从小到大排序）
		for (Map.Entry<Character, Integer> entry : frequencies.entrySet()) {

			char symbol   = entry.getKey();// 获取遍历到的字符
            int frequency = entry.getValue();// 获取字符出现频率
            
            HNode hNode = new HNode(symbol, frequency);
            
            pQueue.add(hNode);
		}
		
		while (pQueue.size() > 1) {
			HNode left = pQueue.poll(); // 取出频率最小的节点
            HNode right = pQueue.poll();// 取出频率第二小的节点
            HNode parent = new HNode(left, right); // 合并成新节点
            pQueue.add(parent); // 放回队列
		}
//        剩一个节点空(18)，将其取出并赋值给root
		root = pQueue.poll();
	}

	/**
     * 递归方式将符号编码为其二进制字符串表示。
     * @param symbol 要编码的字符
     * @return 表示符号的二进制字符串
     */
    public String encode (char symbol) {return encode (symbol, root);
	}

    private String encode (char symbol, HNode curr) {
		if (curr.isLeaf()) {
			return "";
		}
		else {
            HNode left = curr.getLeft();
            HNode right = curr.getRight();

			if (left.contains(symbol)) {
				return "0" + encode (symbol, left);
			}
			
			else {
				return "1" + encode (symbol, right);
			}
		}
	}
    /**
     * 将长二进制字符串解码为对应的文本。
     * @param bitString 要解码的完整二进制字符串
     * @return 解码的文本
     */
    public String decodeText(String bitString) {
        StringBuilder decoded = new StringBuilder();
        HNode currentNode = root;

        for (int i = 0; i < bitString.length(); i++) {
            char bit = bitString.charAt(i);

            if (bit == '0') {
                currentNode = currentNode.getLeft();
            } else if (bit == '1') {
                currentNode = currentNode.getRight();
            }

            if (currentNode == null) {
                // Invalid path, reset or handle error
                currentNode = root;
                continue;
            }

            if (currentNode.isLeaf()) {
                decoded.append(currentNode.getSymbol());
                currentNode = root;
            }
        }

        return decoded.toString();
    }

	/**
     * 将字符的霍夫曼编码写入BitOutputStream。
     * @param symbol 要编码的字符
     */
    public void writeCode (char symbol, BitOutputStream stream) throws IOException {
		HNode curHNode = root;
		
		while (!curHNode.isLeaf()) {
			HNode curLeft = curHNode.getLeft();
            HNode curRight = curHNode.getRight();

			if (curLeft.contains(symbol)) {
	            stream.writeBit(0);
	            curHNode = curLeft;
	        }
	        else {
	        	stream.writeBit(1);
	            curHNode = curRight;
	        }
		}
	}

	/**
     * 根据霍夫曼编码从BitInputStream读取下一个字符。
     * @param stream 用于读取位的BitInputStream
     * @return 解码的字符
     */
	public char readCode (BitInputStream stream) throws IOException {
		HNode curHNode = root;
		
		while (!curHNode.isLeaf()) {
			if (stream.readBit() == 0) {
				curHNode = curHNode.getLeft();
			}
			else {
				curHNode = curHNode.getRight();
			}
		}
		return curHNode.getSymbol();
	}
}