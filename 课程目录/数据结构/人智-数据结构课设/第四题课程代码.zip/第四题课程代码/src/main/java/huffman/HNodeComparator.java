package huffman;

import java.util.Comparator;

/**
 * * @param a 第一个HNode
 * * @param b 第二个HNode
 * 节点首先按频率（升序）进行比较。
 * 如果频率相等，则按符号的字典顺序进行比较。
 */
public class HNodeComparator implements Comparator<HNode> {
    @Override
    public int compare(HNode a, HNode b) 
	{
        int freqCompare = Integer.compare(a.getFrequency(), b.getFrequency());

        if (freqCompare != 0) {
        	return freqCompare;// 频率不同，直接返回频率比较结果
        }
//      频率完全相同  遵循「Unicode 编码字典序」进行比较

        //当a的symbols字典序 < b的symbols：返回负数；
        //当a的symbols字典序 = b的symbols：返回 0；
        //当a的symbols字典序 > b的symbols：返回正数。
        return a.getSymbols().compareTo(b.getSymbols());
    }
}