package utils;

import java.io.IOException;
import java.io.FileNotFoundException;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.ObjectInputStream;

/**
 * BitInputStream允许从通用Java InputStream中读取单个位。
 * 此类能够从流中读取单个位，也能够读取可序列化对象。
 * <p>
 * 代码基于以下参考:
 * <p>
 * http://www.developer.nokia.com/Community/Wiki/Bit_Input/Output_Stream_utility_classes_for_efficient_data_transfer
 * <p>    
 * 原作者是Andreas Jakl。代码已被修改以支持流末尾的部分字节
 * 并允许读取可序列化对象。
 * 
 */
public class BitInputStream {
	/**
	 * 此流从中读取的<code>ObjectInputStream</code>。
	 */
	private ObjectInputStream stream;

	/**
	 * 包含此流当前字节的缓冲区。
	 */
	private int buffer;

	/**
	 * 此流中的最后一个字节，不是原始输入的一部分。
	 * 表示在最后保存的有用位数。
	 */
	private int lastBits;

	/**
	 * 流中的下一个字节（如果有的话）。
	 */
	private int nextByte;

    /**
	 * 跟踪流中是否还有下一个字节。
	 */
	private boolean hasNextByte = false;

	/**
	 * 指示方法<code>readBit</code>是否已被调用。
	 * 在调用<code>readBit</code>之后不能调用方法<code>readObject</code>。
	 */
	private boolean readBitCalled = false;

	/**
	 * 将由<code>readBit</code>返回的当前字节中下一个位的索引。
	 * 如果为0，则下一个位将从<code>ObjectInputStream</code>的下一个字节中读取。
	 */
	private int nextBit = 8;

	/**
	 * 创建一个从指定<code>InputStream</code>读取位的<code>BitInputStream</code>。
	 * @param in 要读取的输入流
	 * @throws IOException - 如果写入流头时发生I/O错误 
     * @throws SecurityException - 如果不受信任的子类非法覆盖安全敏感方法 
     * @throws NullPointerException - 如果<code>in</code>为<code>null</code>
	 */
	public BitInputStream(InputStream in) throws IOException {
		stream = new ObjectInputStream(in);
	}

	/**
	 * 创建一个从给定名称的文件读取位的<code>BitInputStream</code>。
	 * @param name 要从中读取位的文件名
	 * @throws IOException 如果发生I/O错误
	 * @throws FileNotFoundException 如果文件不存在，是目录而不是常规文件，
	 *         或由于其他原因无法打开进行读取。
	 */
	public BitInputStream(String name) throws IOException {
		stream = new ObjectInputStream(new FileInputStream(name));
	}

	/**
	 * 如果此流中还有更多位，则返回<code>true</code>。在调用<code>hasNext</code>之后
	 * 不应调用方法<code>readObject</code>。
	 * @return <code>true</code>，如果此流中还有更多位
	 */
	synchronized public boolean hasNext() {
		if (stream == null) {
			return false;
		}	
		else if (!readBitCalled) {
			try {
				buffer = stream.readUnsignedByte();
			}
			catch (IOException e) {
				return false;
			}
			try {
				lastBits = stream.readUnsignedByte();
			}
			catch (IOException e) {
				return false;
			}
			try {
				nextByte = stream.readUnsignedByte();
				nextBit = 8;
				hasNextByte = true;
			}
			catch (IOException e) {
				nextBit = lastBits;
				lastBits = 0;
				hasNextByte = false;
			}
			readBitCalled = true;
			return true;
		}
		else if (nextBit == 0) {
			if (!hasNextByte) {
				return false;
			}
			else {
				buffer = lastBits;
				lastBits = nextByte;
				try {
				        nextByte = stream.readUnsignedByte();
					nextBit = 8;
					hasNextByte = true;
				}
				catch (IOException e) {
					nextBit = lastBits;
					hasNextByte = false;
				}
				return true;
			}
		}
		else {
			return true;
		}
	}

	/**
	 * 从此流读取下一位。
	 * @return 如果位为0则返回0，如果位为1则返回1
	 * @throws IOException 如果发生I/O错误，或尝试读取文件末尾之后的内容
	 */
	synchronized public int readBit() throws IOException {
		if (!hasNext()) {
			throw new IOException("流中没有剩余的比特位");
		}
		else {
			nextBit--;
			int bit = buffer & (1 << nextBit);
			bit = (bit == 0) ? 0 : 1;
			return bit;
		}
	}

	/**
	 * 从此流读取下一个对象。
	 * @return 从此流读取的对象
	 */
	synchronized public Object readObject() throws IOException, ClassNotFoundException {
		if (stream == null) {
			throw new IOException("this stream is not open for reading");
		}
		else if (readBitCalled) {
			throw new IOException("cannot call readObject after a call to readBit");
		}

		return stream.readObject();
	}

	/**
	 * 关闭底层输入流。
	 * @throws IOException 如果发生I/O错误
	 */
	public void close() throws IOException {
		stream.close();
		stream = null;
	}
}