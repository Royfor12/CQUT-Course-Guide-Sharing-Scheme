package com.example.huffman.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages = {"com.example.huffman", "huffman", "huffmanzip", "utils"})
public class HuffmanConfig {
    // 霍夫曼压缩组件的配置
}