package huffman;

import lombok.Getter;
import lombok.ToString;

/**
 * 表示霍夫曼树中的一个节点。
 * 节点可以是叶节点（包含单个符号）或内部父节点（包含其子节点的组合符号）。
 */
@Getter
@ToString
public class HNode {
	/** 子节点。如果这是叶节点，则为null。 */
    private HNode left, right;
	
	/** 此节点中包含的符号。 */
	private String symbols;
	/** 此节点中符号的累积频率。 */
	private int    frequency;

    /**
     * 构造一个包含单个字符及其频率的叶节点。
     */
    public HNode (char c, int f) {
		this.left  = null;
		this.right = null;
		
		this.symbols = "" + c;
		this.frequency = f;
	}

    /**
     * 通过组合两个子节点构造一个内部父节点。
     * 符号和频率是子节点符号和频率的总和。
     */
    public HNode (HNode left, HNode right) {
		this.left  = left;
		this.right = right;
		
		this.symbols   = left.symbols + right.symbols;
		this.frequency = left.frequency + right.frequency;
	}
    

	/**
     * 检查此节点是否为叶节点（没有子节点）。
     * @return 如果是叶节点返回true，否则返回false
     */
    public boolean isLeaf () {return left == null && right == null;}

	/**
     * 检查此节点是否包含特定字符。
     * @param ch 要检查的字符
     * @return 如果字符存在于此节点的符号中返回true
     */
    public boolean contains (char ch) {return symbols.contains("" + ch);}

	/**
     * 如果此节点是叶节点，则返回此节点的符号。
     * @return 如果是叶节点返回单个字符，否则返回'\0'
     */
    public char getSymbol () {
		if (!isLeaf()) {
			return '\0';
		}
		return symbols.charAt(0);}}