package com.example.huffman.controller;

import com.example.huffman.service.HuffmanCompressionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.net.MalformedURLException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 霍夫曼文本压缩控制器
 * 核心功能：提供HTTP接口实现「批量测试文件压缩」、「单个文件上传压缩」、「.hz压缩文件解压缩」、「压缩/解压缩文件下载」、「测试文件列表查询」
 * 接口前缀：/api/compression
 * 跨域支持：允许所有来源跨域请求（生产环境建议指定具体域名）
 */
@RestController
@RequestMapping("/api/compression")
@CrossOrigin(origins = "*")
public class TextCompressionController {

    /**
     * 注入霍夫曼压缩业务服务
     * 该服务提供底层的文本文件压缩、解压缩核心逻辑（封装霍夫曼编码/解码算法）
     */
    @Autowired
    private HuffmanCompressionService compressionService;

    /**
     * 线程安全的文件存储映射表
     * Key：文件唯一标识（UUID生成的fileId），用于下载时定位文件
     * Value：文件的磁盘路径（Path类型），指向压缩/解压缩后的文件
     * 选用ConcurrentHashMap：Spring MVC默认多线程处理请求，保证并发环境下的线程安全
     */
    private static final Map<String, Path> fileStorage = new ConcurrentHashMap<>();


    /**
     * 单个文件上传压缩接口
     * 接口类型：POST
     * 接口路径：/api/compression/compress/file
     * 请求参数：file（MultipartFile类型，前端上传的文件）
     * 返回值：单个文件压缩结果+下载链接
     * @param file 前端上传的待压缩文件（支持文本类型）
     * @return ResponseEntity<Map<String, Object>> 压缩结果+下载信息
     */
    @PostMapping("/compress/file")
    public ResponseEntity<Map<String, Object>> compressFile(@RequestParam("file") MultipartFile file) {
        Map<String, Object> response = new HashMap<>();

        try {
            // 1. 调用业务服务处理上传文件并进行压缩
            Map<String, Object> result = compressionService.handleUploadedFile(file);

            // 2. 从结果中获取压缩文件路径并存入存储映射
            String fileId = (String) result.get("fileId");
            String compressedFilePath = (String) result.get("compressedFilePath");
            fileStorage.put(fileId, Paths.get(compressedFilePath));

            // 3. 封装压缩结果和下载信息
            response.put("fileName", result.get("fileName")); // 原始文件名
            response.put("originalSize", result.get("originalSize")); // 原始大小
            response.put("compressedSize", result.get("compressedSize")); // 压缩后大小
            response.put("compressionRatio", result.get("compressionRatio")); // 压缩比
            response.put("savedPercentage", result.get("savedPercentage")); // 空间节省率
            response.put("downloadUrl", "/api/compression/download/" + fileId); // 压缩文件下载链接
            response.put("downloadName", result.get("fileName") + ".hz"); // 下载时的文件名

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            // 压缩异常：文件写入失败、压缩算法异常等
            response.put("error", "文件压缩失败：" + e.getMessage());
            return ResponseEntity.internalServerError().body(response);
        }
    }

    /**
     * 单个.hz压缩文件上传解压缩接口
     * 接口类型：POST
     * 接口路径：/api/compression/decompress/file
     * 请求参数：file（MultipartFile类型，仅支持.hz后缀压缩文件）
     * 返回值：解压缩结果+原始文件下载链接
     * @param file 前端上传的.hz霍夫曼压缩文件
     * @return ResponseEntity<Map<String, Object>> 解压缩结果+下载信息
     */
    @PostMapping("/decompress/file")
    public ResponseEntity<Map<String, Object>> decompressFile(@RequestParam("file") MultipartFile file) {
        Map<String, Object> response = new HashMap<>();

        try {
            // 1. 调用业务服务处理上传的压缩文件并进行解压缩
            Map<String, Object> result = compressionService.handleUploadedCompressedFile(file);

            // 2. 从结果中获取解压缩文件路径并存入存储映射
            String fileId = (String) result.get("fileId");
            String decompressedFilePath = (String) result.get("decompressedFilePath");
            fileStorage.put(fileId, Paths.get(decompressedFilePath));

            // 3. 封装解压缩结果和下载信息
            response.put("fileName", result.get("fileName")); // 原始文件名
            response.put("downloadUrl", "/api/compression/download/" + fileId); // 原始文件下载链接
            response.put("downloadName", result.get("fileName")); // 下载文件名
            response.put("success", result.get("success")); // 解压缩成功标记

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            // 解压缩异常：文件格式错误、解压缩算法异常、文件写入失败等
            response.put("error", "文件解压缩失败：" + e.getMessage());
            return ResponseEntity.internalServerError().body(response);
        }
    }

    /**
     * 根据文件唯一ID下载压缩/解压缩文件
     * 接口类型：GET
     * 接口路径：/api/compression/download/{fileId}
     * 路径参数：fileId（文件唯一标识，UUID生成）
     * 返回值：文件资源（以附件形式下载）
     * @param fileId 文件唯一标识
     * @return ResponseEntity<Resource> 文件下载响应
     */
    @GetMapping("/download/{fileId}")
    public ResponseEntity<Resource> downloadFile(@PathVariable String fileId) {
        // 1. 从存储映射表中获取文件路径
        Path filePath = fileStorage.get(fileId);
        // 2. 校验文件路径是否存在且文件实际存在
        if (filePath == null || !Files.exists(filePath)) {
            // 返回404 Not Found未找到响应
            return ResponseEntity.notFound().build();
        }

        try {
            // 3. 根据文件路径创建UrlResource资源（Spring支持的文件资源类型）
            Resource resource = new UrlResource(filePath.toUri());

            // 4. 校验资源是否存在且可读
            if (resource.exists() && resource.isReadable()) {
                // 5. 构建响应：返回二进制流+附件下载头
                return ResponseEntity.ok()
                        // 设置响应媒体类型为二进制流（支持所有文件类型下载）
                        .contentType(MediaType.APPLICATION_OCTET_STREAM)
                        // 设置Content-Disposition头，指定附件文件名，实现浏览器下载弹窗
                        .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + filePath.getFileName().toString() + "\"")
                        // 响应体为文件资源
                        .body(resource);
            } else {
                // 资源不可读或不存在，返回404
                return ResponseEntity.notFound().build();
            }
        } catch (MalformedURLException e) {
            // 路径转换URL异常（无效路径），返回500服务器错误
            return ResponseEntity.internalServerError().build();
        }
    }
}