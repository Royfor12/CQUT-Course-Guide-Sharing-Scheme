#include "stm32f10x.h"
#include "Delay.h"

// 数码管段码表（共阴极）
const uint8_t seg_table[10] = {
    0x3F, // 0
    0x06, // 1
    0x5B, // 2
    0x4F, // 3
    0x66, // 4
    0x6D, // 5
    0x7D, // 6
    0x07, // 7
    0x7F, // 8
    0x6F  // 9
};

// 系统状态
typedef enum {
    STATE_SETTING, // 设置模式
    STATE_TIMING,  // 计时模式
    STATE_ALARM    // 提醒模式
} SystemState;

// 全局变量
SystemState current_state = STATE_SETTING;
uint16_t set_time = 0;      // 设置的定时时间 (单位: 秒)
uint16_t current_time = 0;  // 当前计时时间 (单位: 秒)
uint8_t display_buffer[4];  // 数码管显示缓冲区
uint32_t ms_counter = 0;    // 毫秒计数器
uint8_t led_flash_flag = 0; // LED闪烁标志

void GPIO_Init_All(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;

    // 使能GPIO时钟
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB | RCC_APB2Periph_AFIO, ENABLE);

    // 关闭JTAG调试功能，释放PA15, PB3, PB4。这对使用这些引脚很重要。
    GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable, ENABLE);

    // LED初始化 - 推挽输出
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8 | GPIO_Pin_11 | GPIO_Pin_12 | GPIO_Pin_15;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    // 按键初始化 - 上拉输入
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_4 | GPIO_Pin_5;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    // 数码管段选初始化 - 推挽输出
    // 这些引脚在板子上与电机驱动冲突！
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3 | 
                                  GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    // 数码管位选初始化 - 推挽输出
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12 | GPIO_Pin_13 | GPIO_Pin_14;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    // 初始状态：熄灭所有LED和数码管
    GPIO_SetBits(GPIOA, GPIO_Pin_8 | GPIO_Pin_11 | GPIO_Pin_12 | GPIO_Pin_15);
    GPIO_Write(GPIOA, GPIO_ReadOutputData(GPIOA) & 0xFF00); // 熄灭段选 (清零低8位)
    GPIO_ResetBits(GPIOB, GPIO_Pin_12 | GPIO_Pin_13 | GPIO_Pin_14); // 关闭位选
}

uint8_t Key_Scan(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin)
{
    if(GPIO_ReadInputDataBit(GPIOx, GPIO_Pin) == 0)
    {
        Delay_ms(20); // 延时去抖动
        if(GPIO_ReadInputDataBit(GPIOx, GPIO_Pin) == 0)
        {
            while(GPIO_ReadInputDataBit(GPIOx, GPIO_Pin) == 0); // 等待按键释放
            return 1;
        }
    }
    return 0;
}

// 此函数仅更新要显示的数据到缓冲区，不执行实际显示
void Display_Update(uint16_t number)
{
    // 分解数字到显示缓冲区，顺序为 个、十、百、千
    display_buffer[0] = number % 10;
    display_buffer[1] = (number / 10) % 10;
    display_buffer[2] = (number / 100) % 10;
    display_buffer[3] = (number / 1000) % 10;
}

// 将此函数放在主循环中进行动态扫描，每次只显示一位
void Display_Scan(void)
{
    static uint8_t i = 0; // 使用静态变量来记录当前扫描到哪一位

    // 关闭所有位选，防止重影
    GPIO_ResetBits(GPIOB, GPIO_Pin_12 | GPIO_Pin_13 | GPIO_Pin_14);

    // 先送段码，再开位选，可以进一步减少重影
    GPIO_ResetBits(GPIOA, 0x00FF);  // 清除上一次的段码
    
    // 使用 display_buffer[i] 来确保显示顺序与硬件连接顺序（右->左）一致
    // i=0 (硬件上的个位) 显示 buffer[0] (个位的值)
    // i=1 (硬件上的十位) 显示 buffer[1] (十位的值) ...
    GPIO_SetBits(GPIOA, seg_table[display_buffer[i]]);

    // 根据i的值选择对应的数码管位
    switch(i)
    {
        case 0: /* 000 - Y0 (个位) */ break; // ResetBits已处理
        case 1: GPIO_SetBits(GPIOB, GPIO_Pin_12);                      break; // 001 - Y1 (十位)
        case 2: GPIO_SetBits(GPIOB, GPIO_Pin_13);                      break; // 010 - Y2 (百位)
        case 3: GPIO_SetBits(GPIOB, GPIO_Pin_12 | GPIO_Pin_13);        break; // 011 - Y3 (千位)
    }

    i++; // 准备下一次扫描下一位
    if(i > 3)
    {
        i = 0;
    }
}


int main(void)
{
    // 系统初始化
    GPIO_Init_All();
    // Delay库基于SysTick，不需要显式初始化，所以没有Delay_Init()

    while(1)
    {
        // 状态机，处理核心逻辑
        switch(current_state)
        {
            case STATE_SETTING:
                Display_Update(set_time); // 更新要显示的时间
                
                if(Key_Scan(GPIOB, GPIO_Pin_0)) { set_time = 0; }
                if(Key_Scan(GPIOB, GPIO_Pin_4)) { if(set_time < 9999) set_time++; }
                if(Key_Scan(GPIOB, GPIO_Pin_5)) { if(set_time > 0) set_time--; }
                if(Key_Scan(GPIOB, GPIO_Pin_1))
                {
                    if(set_time > 0) // 只有设置时间大于0才开始
                    {
                        current_time = set_time; // 从设定时间开始倒计时
                        ms_counter = 0;
                        current_state = STATE_TIMING;
                    }
                }
                break;
                
            case STATE_TIMING:
                Display_Update(current_time); // 显示倒计时
                
                if(ms_counter >= 1000) // 每1000ms (1秒)
                {
                    ms_counter = 0;
                    if(current_time > 0)
                    {
                        current_time--;
                    }
                    if(current_time == 0) // 倒计时结束
                    {
                        current_state = STATE_ALARM;
                        led_flash_flag = 0;
                    }
                }
                
                if(Key_Scan(GPIOB, GPIO_Pin_0)) // K1中途停止
                {
                    current_state = STATE_SETTING;
                }
                break;
                
            case STATE_ALARM:
                Display_Update(0); // 提醒时显示0000
                
                if(ms_counter >= 500) // 每500ms
                {
                    ms_counter = 0;
                    led_flash_flag = !led_flash_flag; // 翻转闪烁标志
                    if(led_flash_flag)
                    {
                        GPIO_ResetBits(GPIOA, GPIO_Pin_8 | GPIO_Pin_11 | GPIO_Pin_12 | GPIO_Pin_15);
                    }
                    else
                    {
                        GPIO_SetBits(GPIOA, GPIO_Pin_8 | GPIO_Pin_11 | GPIO_Pin_12 | GPIO_Pin_15);
                    }
                }
                
                if(Key_Scan(GPIOB, GPIO_Pin_0) || Key_Scan(GPIOB, GPIO_Pin_1) || 
                   Key_Scan(GPIOB, GPIO_Pin_4) || Key_Scan(GPIOB, GPIO_Pin_5))
                {
                    GPIO_SetBits(GPIOA, GPIO_Pin_8 | GPIO_Pin_11 | GPIO_Pin_12 | GPIO_Pin_15); // 确保熄灭LED
                    current_state = STATE_SETTING;
                }
                break;
        }
        
        // --- 主循环中固定执行的任务 ---
        Display_Scan(); // 每次循环只显示一位数码管
        Delay_ms(2);    // 扫描间隔。4位一轮需要8ms，刷新率约125Hz，无闪烁
        ms_counter += 2;// 累加经过的时间
    }
}