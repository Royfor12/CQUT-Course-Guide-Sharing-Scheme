#include "stm32f10x.h"
#include "Delay.h"
#include <stdio.h>

// 全局变量
// 数码管段码表（共阴极，索引0~9对应数字0~9的段码）
const uint8_t seg_table[10] = {0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,0x7F,0x6F};
typedef enum {STATE_SETTING, STATE_TIMING, STATE_ALARM} SystemState;

// 核心变量（加volatile：防止编译器优化，确保中断与主循环同步访问）
volatile SystemState current_state = STATE_SETTING;	// 初始状态：设置模式
volatile uint16_t set_time = 0;											// 设定的定时时间（单位：秒）
volatile uint16_t current_time = 0;									// 当前计时时间（单位：秒）
volatile uint8_t display_buffer[4];									// 数码管显示缓冲区（[0]=个位，[1]=十位，[2]=百位，[3]=千位）
volatile uint32_t ms_counter = 0;										// 毫秒计数器（计时基准，每2ms累加2）
volatile uint8_t led_flash_flag = 0;								// LED闪烁标志（0=熄灭，1=点亮）

// UART相关变量（中断接收+主循环处理，避免中断阻塞）
volatile uint8_t uart_received_cmd = 0;							// 存储串口接收的命令（1~6）
volatile uint8_t uart_cmd_ready = 0;								// 串口命令就绪标志（0=未就绪，1=就绪）

// 按键标志位
volatile uint8_t key_flag = 0;
#define KEY_K1  0x01// K1按键标志（PB0，进入设置模式）
#define KEY_K2  0x02// K2按键标志（PB1，开始计时）
#define KEY_K3  0x04// K3按键标志（PB4，定时时间+2）
#define KEY_K4  0x08// K4按键标志（PB5，定时时间-2）

// GPIO初始化
void GPIO_Init_All(void) {
    GPIO_InitTypeDef GPIO_InitStructure;
		// 使能GPIOA、GPIOB、AFIO时钟（AFIO用于EXTI引脚映射和UART复用）
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB | RCC_APB2Periph_AFIO, ENABLE);
		// 关闭JTAG调试功能，释放PA15、PB3、PB4（避免引脚冲突）
    GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable, ENABLE);

    // GPIOA: 数码管(PA0~7) + LED(PA8/11/12/15) + UART(PA9/10)
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3 | 
                                  GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; // 推挽输出：能输出高低电平，驱动能力强
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8 | GPIO_Pin_11 | GPIO_Pin_12 | GPIO_Pin_15;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    GPIO_SetBits(GPIOA, GPIO_Pin_8 | GPIO_Pin_11 | GPIO_Pin_12 | GPIO_Pin_15); // 初始熄灭LED
    
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP; // 复用推挽：引脚功能交给UART模块
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING; // 浮空输入：不接上下拉，由外部信号决定电平
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    // GPIOB: 按键(PB0/1/4/5) + 数码管位选(PB12~14)
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_4 | GPIO_Pin_5;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
    
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12 | GPIO_Pin_13 | GPIO_Pin_14;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
}

// UART1初始化函数
void UART1_Init(void) {
    USART_InitTypeDef USART_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;

		// 使能UART1时钟（UART1挂载APB2总线，时钟使能函数与APB1不同）
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);

		// UART参数配置（与串口助手保持一致，否则通信乱码）
    USART_InitStructure.USART_BaudRate = 115200; 																		// 波特率：115200bps
    USART_InitStructure.USART_WordLength = USART_WordLength_8b; 										// 数据位：8位（标准ASCII通信）
    USART_InitStructure.USART_StopBits = USART_StopBits_1; 													// 停止位：1位（兼容大多数设备）
    USART_InitStructure.USART_Parity = USART_Parity_No;															// 校验位：无（简化通信，减少误判）
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None; // 无硬件流控（无需RTS/CTS）
    USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;									// 使能接收和发送模式
    USART_Init(USART1, &USART_InitStructure);																				// 初始化UART1

		// 使能UART1接收非空中断（接收到1字节数据时触发中断）
    USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);

		// NVIC配置（UART1中断优先级：抢占0，响应0，最高优先级，确保命令不丢失）
    NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn; 				// 中断通道：UART1
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;						// 使能中断通道
    NVIC_Init(&NVIC_InitStructure);

    USART_Cmd(USART1, ENABLE);
}

// printf重定向函数, 使printf通过UART1发送
int fputc(int ch, FILE *f) {
    uint16_t timeout = 5000; // 超时计数，防止UART异常时死循环
		// 等待发送数据寄存器为空（USART_FLAG_TXE：发送寄存器空，可写入新数据）
    while(USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET && timeout--);
    if(timeout > 0) USART_SendData(USART1, (uint8_t)ch);
    return ch;
}

// EXTI初始化
void EXTI_K1_Init(void) {
    EXTI_InitTypeDef EXTI_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;

		// 映射PB0到EXTI0（AFIO功能：将GPIO引脚与EXTI线关联）
    GPIO_EXTILineConfig(GPIO_PortSourceGPIOB, GPIO_PinSource0);
    EXTI_InitStructure.EXTI_Line = EXTI_Line0;
    EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;
    EXTI_Init(&EXTI_InitStructure);

		// NVIC配置（抢占1，响应1，低于UART中断，避免影响串口命令）
    NVIC_InitStructure.NVIC_IRQChannel = EXTI0_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
}

void EXTI_K2_Init(void) {
    EXTI_InitTypeDef EXTI_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;

    GPIO_EXTILineConfig(GPIO_PortSourceGPIOB, GPIO_PinSource1);
    EXTI_InitStructure.EXTI_Line = EXTI_Line1;
    EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising;
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;
    EXTI_Init(&EXTI_InitStructure);

    NVIC_InitStructure.NVIC_IRQChannel = EXTI1_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
}

void EXTI_K3_Init(void) {
    EXTI_InitTypeDef EXTI_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;

    GPIO_EXTILineConfig(GPIO_PortSourceGPIOB, GPIO_PinSource4);
    EXTI_InitStructure.EXTI_Line = EXTI_Line4;
    EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising_Falling; // ✅ 双边触发
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;
    EXTI_Init(&EXTI_InitStructure);

    NVIC_InitStructure.NVIC_IRQChannel = EXTI4_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 3;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
}

void EXTI_K4_Init(void) {
    EXTI_InitTypeDef EXTI_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;

    GPIO_EXTILineConfig(GPIO_PortSourceGPIOB, GPIO_PinSource5);
    EXTI_InitStructure.EXTI_Line = EXTI_Line5;
    EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising_Falling; // ✅ 双边触发
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;
    EXTI_Init(&EXTI_InitStructure);

		// EXTI5~9共享EXTI9_5_IRQn通道（STM32硬件设计，需通过中断标志区分）
    NVIC_InitStructure.NVIC_IRQChannel = EXTI9_5_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 4;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
}

void Display_Update(volatile uint16_t number) {
    display_buffer[0] = number % 10;
    display_buffer[1] = (number / 10) % 10;
    display_buffer[2] = (number / 100) % 10;
    display_buffer[3] = (number / 1000) % 10;
}

void Display_Scan(void) {
    static uint8_t i = 0; // 静态变量：记录当前扫描的数码管位（0=个位，1=十位，2=百位，3=千位）
		// 1. 关闭所有位选：防止上一位数码管残留亮着（避免重影）
    GPIO_ResetBits(GPIOB, GPIO_Pin_12 | GPIO_Pin_13 | GPIO_Pin_14);
		// 2. 清除段选残留：读取GPIOA当前状态，仅清零低8位（段选），保留高8位（LED）
    uint16_t temp = GPIO_ReadOutputData(GPIOA);
    GPIO_Write(GPIOA, temp & 0xFF00);
		// 3. 输出当前位的段码：从段码表中获取对应数字的段码
    GPIO_SetBits(GPIOA, seg_table[display_buffer[i]]);
    
    switch(i) {
        case 1: GPIO_SetBits(GPIOB, GPIO_Pin_12); break; // 十位：仅PB12=1（对应38译码器Y1）
        case 2: GPIO_SetBits(GPIOB, GPIO_Pin_13); break; // 百位：仅PB13=1（对应38译码器Y2）
        case 3: GPIO_SetBits(GPIOB, GPIO_Pin_12 | GPIO_Pin_13); break; // 千位：PB12=1且PB13=1（对应38译码器Y3）
				// case 0（个位）：无需设置位选，PB12~14均为0，对应38译码器Y0
    }
		// 5. 切换到下一位（循环扫描4位）
    i = (i + 1) % 4;
}

// UART命令处理函数
void UART_Command_Handler(void) {
    if(uart_cmd_ready) { // 命令就绪：中断已接收有效命令
        uart_cmd_ready = 0; // 清除标志，避免重复处理
        switch(uart_received_cmd) {
						// 命令1：进入设置模式
            case 1: current_state = STATE_SETTING; printf("Enter Setting Mode\r\n"); break;
						// 命令2：开始计时（仅设置模式且时间>0有效）
            case 2: 
                if(current_state == STATE_SETTING && set_time > 0) {
                    current_time = 0; ms_counter = 0; current_state = STATE_TIMING;
                    printf("Start Timing: %d seconds\r\n", set_time);
                } else { printf("Error: Please set time first!\r\n"); }
                break;
						// 命令3：定时时间-1（仅设置模式）
            case 3: if(current_state == STATE_SETTING && set_time > 0) { set_time--; printf("Time: %d\r\n", set_time); } break;
						// 命令4：定时时间+1（仅设置模式）
            case 4: if(current_state == STATE_SETTING && set_time < 9999) { set_time++; printf("Time: %d\r\n", set_time); } break;
						// 命令5：发送当前设定时间
            case 5: printf("Set Time: %d\r\n", set_time); break;
						// 命令6：发送当前计时时间
            case 6: printf("Current Time: %d\r\n", current_time); break;
        }
    }
}

// 按键处理
void Key_Handler(void) {
    static uint32_t last_key_time[4] = {0};
    static uint8_t edge_count[4] = {0}; // 边沿计数（下降+上升=2）
    
    // K1处理（单边触发，直接处理）
    if(key_flag & KEY_K1) {
        if(ms_counter - last_key_time[0] > 20) {
            current_state = STATE_SETTING;
            set_time = 0;
            last_key_time[0] = ms_counter;
        }
        key_flag &= ~KEY_K1;
    }
    
    // K2处理（单边触发，直接处理）
    if(key_flag & KEY_K2) {
        if(ms_counter - last_key_time[1] > 20) {
            if(current_state == STATE_SETTING && set_time > 0) {
                current_time = 0;
                ms_counter = 0;
                current_state = STATE_TIMING;
            }
            last_key_time[1] = ms_counter;
        }
        key_flag &= ~KEY_K2;
    }
    
    // K3处理（双边触发，需要计数）
    if(key_flag & KEY_K3) {
        if(ms_counter - last_key_time[2] > 10) { // 双边触发去抖时间可缩短（10ms），避免错过边沿
            edge_count[2]++;
            
            // 每2次边沿（一次完整按键动作）执行一次
            if(edge_count[2] >= 2) {
                edge_count[2] = 0;
                if(current_state == STATE_SETTING && set_time < 9998) {
                    set_time += 2;
                }
            }
            last_key_time[2] = ms_counter;
        }
        key_flag &= ~KEY_K3;
    }
    
    // K4处理（双边触发，需要计数）
    if(key_flag & KEY_K4) {
        if(ms_counter - last_key_time[3] > 10) {
            edge_count[3]++;
            
            if(edge_count[3] >= 2) {
                edge_count[3] = 0;
                if(current_state == STATE_SETTING && set_time > 1) {
                    set_time -= 2;
                }
            }
            last_key_time[3] = ms_counter;
        }
        key_flag &= ~KEY_K4;
    }
}

// 中断服务函数（只设置标志位）
void EXTI0_IRQHandler(void) {
    if(EXTI_GetITStatus(EXTI_Line0) != RESET) {
        key_flag |= KEY_K1;
        EXTI_ClearITPendingBit(EXTI_Line0);
    }
}

void EXTI1_IRQHandler(void) {
    if(EXTI_GetITStatus(EXTI_Line1) != RESET) {
        key_flag |= KEY_K2;
        EXTI_ClearITPendingBit(EXTI_Line1);
    }
}

void EXTI4_IRQHandler(void) {
    if(EXTI_GetITStatus(EXTI_Line4) != RESET) {
        key_flag |= KEY_K3; // ✅ 双边触发也只设置标志
        EXTI_ClearITPendingBit(EXTI_Line4);
    }
}

void EXTI9_5_IRQHandler(void) {
    if(EXTI_GetITStatus(EXTI_Line5) != RESET) { // 确认是EXTI5（PB5）触发
        key_flag |= KEY_K4; // ✅ 双边触发也只设置标志
        EXTI_ClearITPendingBit(EXTI_Line5);
    }
}

// UART1中断服务函数（仅接收命令，不处理，避免阻塞）
void USART1_IRQHandler(void) {
    if(USART_GetITStatus(USART1, USART_IT_RXNE) != RESET) { // 接收非空中断
        uint8_t data = USART_ReceiveData(USART1); // 读取接收的1字节数据（ASCII码）
        if(data >= '1' && data <= '6') { // 仅处理有效命令（1~6的ASCII码）
            uart_received_cmd = data - '0'; // ASCII码转数字（'1'→1）
            uart_cmd_ready = 1; // 置位命令就绪标志
        }
        USART_ClearITPendingBit(USART1, USART_IT_RXNE); // 清除中断标志
    }
}

int main(void) {
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2); // 分组2：2位抢占+2位响应
    GPIO_Init_All();
    UART1_Init();
    EXTI_K1_Init();
    EXTI_K2_Init();
    EXTI_K3_Init();
    EXTI_K4_Init();

    Delay_ms(100);
    printf("System Started (Dual-Edge Mode)\r\n");

    while(1) {
        UART_Command_Handler(); // 第一步：处理串口命令（优先响应上位机）
        Key_Handler(); 					// 第二步：处理按键（次之，用户手动操作）
        
        switch(current_state) {
            case STATE_SETTING:
                Display_Update(set_time);
								GPIO_SetBits(GPIOA, GPIO_Pin_8 | GPIO_Pin_11 | GPIO_Pin_12 | GPIO_Pin_15);
                break;
            case STATE_TIMING:
                Display_Update(current_time);
                if(ms_counter >= 1000) {
                    ms_counter = 0;
                    current_time++;
                    if(current_time >= set_time) {
                        current_state = STATE_ALARM;
                        printf("Alarm!\r\n");
                    }
                }
                break;
            case STATE_ALARM:
                Display_Update(0);
                if(ms_counter >= 500) {
                    ms_counter = 0;
                    led_flash_flag = !led_flash_flag;
                    if(led_flash_flag) GPIO_ResetBits(GPIOA, GPIO_Pin_8 | GPIO_Pin_11 | GPIO_Pin_12 | GPIO_Pin_15);
                    else GPIO_SetBits(GPIOA, GPIO_Pin_8 | GPIO_Pin_11 | GPIO_Pin_12 | GPIO_Pin_15);
                }
								// 任意按键退出提醒模式
                if(!GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0) || !GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_1) ||
                   !GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_4) || !GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_5)) {
                    GPIO_SetBits(GPIOA, GPIO_Pin_8 | GPIO_Pin_11 | GPIO_Pin_12 | GPIO_Pin_15);
                    current_state = STATE_SETTING;
                    Delay_ms(200);
                }
                break;
        }

        Display_Scan();
        Delay_ms(2);
        ms_counter += 2;
    }
}