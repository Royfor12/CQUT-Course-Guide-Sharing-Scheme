#include "stm32f10x.h"
#include "Delay.h"

// 1.全局变量（加volatile，中断与主循环共享）
// 数码管段码表（共阴极）
const uint8_t seg_table[10] = {0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,0x7F,0x6F};
// 系统状态枚举
typedef enum {STATE_SETTING, STATE_TIMING, STATE_ALARM} SystemState;
// 共享变量（必须加volatile）
volatile SystemState current_state = STATE_SETTING;
volatile uint16_t set_time = 0;        // 设置时间
volatile uint16_t current_time = 0;    // 当前计时时间
volatile uint8_t display_buffer[4];    // 显示缓冲区
volatile uint32_t ms_counter = 0;      // 毫秒计数器
volatile uint8_t led_flash_flag = 0;   // LED闪烁标志

// 2. GPIO初始化（按键/LED/数码管）
void GPIO_Init_All(void) {
    GPIO_InitTypeDef GPIO_InitStructure;
    // 使能时钟（GPIOA/GPIOB/AFIO，AFIO用于EXTI映射）
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB | RCC_APB2Periph_AFIO, ENABLE);
    // 关闭JTAG，释放PA15（原有逻辑保留）
    GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable, ENABLE);

    // -------------------------- LED初始化（PA8/11/12/15，推挽输出）
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8 | GPIO_Pin_11 | GPIO_Pin_12 | GPIO_Pin_15;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    GPIO_SetBits(GPIOA, GPIO_Pin_8 | GPIO_Pin_11 | GPIO_Pin_12 | GPIO_Pin_15); // 初始熄灭

    // -------------------------- 按键初始化（上拉输入，实验手册2.1.3节）
    // K1(PB0)、K2(PB1)、K3(PB4)、K4(PB5)
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_4 | GPIO_Pin_5;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU; // 上拉输入，防止电平浮动
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    // -------------------------- 数码管初始化
    // 段选(PA0~PA7)
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3 | 
                                  GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    // 位选(PB12~PB14)
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12 | GPIO_Pin_13 | GPIO_Pin_14;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
    // 初始熄灭数码管
    GPIO_Write(GPIOA, GPIO_ReadOutputData(GPIOA) & 0xFF00);
    GPIO_ResetBits(GPIOB, GPIO_Pin_12 | GPIO_Pin_13 | GPIO_Pin_14);
}

// 3. EXTI+NVIC初始化
// 3.1 K1(PB0)中断初始化：EXTI0，下降沿触发（进入设置模式）
void EXTI_K1_Init(void) {
    EXTI_InitTypeDef EXTI_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;

    // 步骤1：AFIO引脚映射（PB0→EXTI0）
    GPIO_EXTILineConfig(GPIO_PortSourceGPIOB, GPIO_PinSource0);

    // 步骤2：EXTI初始化
    EXTI_InitStructure.EXTI_Line = EXTI_Line0;          // 对应PB0
    EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;  // 中断模式（非事件模式）
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling; // 下降沿触发
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;           // 使能中断线
    EXTI_Init(&EXTI_InitStructure);

    // 步骤3：NVIC初始化
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2); // 分组2：2位抢占+2位响应
    NVIC_InitStructure.NVIC_IRQChannel = EXTI0_IRQn; // 中断通道：EXTI0
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1; // 抢占优先级1
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;      // 响应优先级1
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;         // 使能通道
    NVIC_Init(&NVIC_InitStructure);
}

// 3.2 K2(PB1)中断初始化：EXTI1，上升沿触发（开始定时）
void EXTI_K2_Init(void) {
    EXTI_InitTypeDef EXTI_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;

    GPIO_EXTILineConfig(GPIO_PortSourceGPIOB, GPIO_PinSource1); // PB1→EXTI1
    EXTI_InitStructure.EXTI_Line = EXTI_Line1;
    EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising; // 上升沿触发（松开时开始）
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;
    EXTI_Init(&EXTI_InitStructure);

    NVIC_InitStructure.NVIC_IRQChannel = EXTI1_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
}

// 3.3 K3(PB4)中断初始化：EXTI4，双边触发（加2）
void EXTI_K3_Init(void) {
    EXTI_InitTypeDef EXTI_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;

    GPIO_EXTILineConfig(GPIO_PortSourceGPIOB, GPIO_PinSource4); // PB4→EXTI4
    EXTI_InitStructure.EXTI_Line = EXTI_Line4;
    EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising_Falling; // 双边触发
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;
    EXTI_Init(&EXTI_InitStructure);

    NVIC_InitStructure.NVIC_IRQChannel = EXTI4_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 3;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
}

// 3.4 K4(PB5)中断初始化：EXTI5，双边触发（减2）
void EXTI_K4_Init(void) {
    EXTI_InitTypeDef EXTI_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;

    GPIO_EXTILineConfig(GPIO_PortSourceGPIOB, GPIO_PinSource5); // PB5→EXTI5
    EXTI_InitStructure.EXTI_Line = EXTI_Line5;
    EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising_Falling; // 双边触发
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;
    EXTI_Init(&EXTI_InitStructure);

    NVIC_InitStructure.NVIC_IRQChannel = EXTI9_5_IRQn; // 注意：EXTI5~9共享此通道（实验手册图11）
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 4;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
}

// 4. 数码管显示函数（适配volatile变量）
void Display_Update(volatile uint16_t number) {
    // 分解数字：display_buffer[0]=个位，[1]=十位，[2]=百位，[3]=千位
    display_buffer[0] = number % 10;
    display_buffer[1] = (number / 10) % 10;
    display_buffer[2] = (number / 100) % 10;
    display_buffer[3] = (number / 1000) % 10;
}

void Display_Scan(void) {
    static uint8_t i = 0;
    // 关闭所有位选，防止重影
    GPIO_ResetBits(GPIOB, GPIO_Pin_12 | GPIO_Pin_13 | GPIO_Pin_14);
    // 清除段码
    GPIO_ResetBits(GPIOA, 0x00FF);
    // 输出当前段码
    GPIO_SetBits(GPIOA, seg_table[display_buffer[i]]);
    // 选通当前数码管
    switch(i) {
        case 0: break;                          // 个位（Y0）
        case 1: GPIO_SetBits(GPIOB, GPIO_Pin_12); break; // 十位（Y1）
        case 2: GPIO_SetBits(GPIOB, GPIO_Pin_13); break; // 百位（Y2）
        case 3: GPIO_SetBits(GPIOB, GPIO_Pin_12 | GPIO_Pin_13); break; // 千位（Y3）
    }
    i = (i + 1) % 4;
}

// 5. 中断服务函数（实验手册2.4节，必须清除中断标志）
// 5.1 K1(EXTI0)中断：进入设置模式，重置时间
void EXTI0_IRQHandler(void) {
    if(EXTI_GetITStatus(EXTI_Line0) != RESET) { // 确认中断来源
        current_state = STATE_SETTING;
        set_time = 0; // 重置设置时间
        EXTI_ClearITPendingBit(EXTI_Line0); // 清除标志，避免重复触发
    }
}

// 5.2 K2(EXTI1)中断：上升沿触发，开始定时
void EXTI1_IRQHandler(void) {
    if(EXTI_GetITStatus(EXTI_Line1) != RESET) {
        if(current_state == STATE_SETTING && set_time > 0) { // 仅设置模式下有效
            current_time = 0;
            ms_counter = 0;
            current_state = STATE_TIMING;
        }
        EXTI_ClearITPendingBit(EXTI_Line1);
    }
}

// 5.3 K3(EXTI4)中断：双边触发，加2（下降沿+1，上升沿+1）
void EXTI4_IRQHandler(void) {
    if(EXTI_GetITStatus(EXTI_Line4) != RESET) {
        if(current_state == STATE_SETTING) { // 仅设置模式下修改时间
            if(GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_4) == 1) { // 上升沿（引脚变高）
                if(set_time < 9998) set_time++;
            } else { // 下降沿（引脚变低）
                if(set_time < 9998) set_time++;
            }
        }
        EXTI_ClearITPendingBit(EXTI_Line4);
    }
}

// 5.4 K4(EXTI5)中断：双边触发，减2（EXTI5~9共享通道，需判断中断线）
void EXTI9_5_IRQHandler(void) {
    if(EXTI_GetITStatus(EXTI_Line5) != RESET) { // 确认是EXTI5（PB5）
        if(current_state == STATE_SETTING) {
            if(GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_5) == 1) { // 上升沿
                if(set_time > 1) set_time--;
            } else { // 下降沿
                if(set_time > 1) set_time--;
            }
        }
        EXTI_ClearITPendingBit(EXTI_Line5); // 清除EXTI5标志
    }
}

// 6. 主函数（状态机+定时+显示+LED控制）
int main(void) {
    // 初始化顺序：GPIO→EXTI→NVIC
    GPIO_Init_All();
    EXTI_K1_Init();
    EXTI_K2_Init();
    EXTI_K3_Init();
    EXTI_K4_Init();

    while(1) {
        // 状态机逻辑
        switch(current_state) {
            case STATE_SETTING:
                Display_Update(set_time); // 显示设置时间
                break;

            case STATE_TIMING:
                Display_Update(current_time); // 显示当前计时时间
                // 定时逻辑：每1000ms current_time加1
                if(ms_counter >= 1000) {
                    ms_counter = 0;
                    current_time++;
                    // 定时到达设置时间，进入闹钟模式
                    if(current_time >= set_time) {
                        current_state = STATE_ALARM;
                        led_flash_flag = 0;
                    }
                }
                break;

            case STATE_ALARM:
                Display_Update(0); // 闹钟时显示0000
                // LED每500ms闪烁一次
                if(ms_counter >= 500) {
                    ms_counter = 0;
                    led_flash_flag = !led_flash_flag;
                    if(led_flash_flag) {
                        GPIO_ResetBits(GPIOA, GPIO_Pin_8 | GPIO_Pin_11 | GPIO_Pin_12 | GPIO_Pin_15);
                    } else {
                        GPIO_SetBits(GPIOA, GPIO_Pin_8 | GPIO_Pin_11 | GPIO_Pin_12 | GPIO_Pin_15);
                    }
                }
                // 任意按键重置（此处用轮询，也可加中断，简化处理）
                if(!GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0) || !GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_1) ||
                   !GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_4) || !GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_5)) {
                    GPIO_SetBits(GPIOA, GPIO_Pin_8 | GPIO_Pin_11 | GPIO_Pin_12 | GPIO_Pin_15);
                    current_state = STATE_SETTING;
                }
                break;
        }

        // 固定执行：数码管扫描+时间累加
        Display_Scan();
        Delay_ms(2);
        ms_counter += 2; // 每2ms累加一次，500次约等于1s
    }
}