#include "stm32f10x.h"
#include <stdio.h>

// -------------------------- 全局变量定义 --------------------------
const uint8_t seg_table[10] = {0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,0x7F,0x6F}; // 共阴极段码表
#define KEY_K1  0x01  // PB0：切换设置项（日→月→年→退出）
#define KEY_K2  0x02  // PB1：开始计时
#define KEY_K3  0x04  // PB4：当前项+1
#define KEY_K4  0x08  // PB5：当前项-1

// 系统状态
typedef enum {
    STATE_IDLE,        // 空闲（显示年→月→日）
    STATE_SETTING_DAY, // 设置日
    STATE_SETTING_MON, // 设置月
    STATE_SETTING_YEAR // 设置年
} SystemState;

// 日期结构体
typedef struct {
    uint16_t year;  // 年（如2024）
    uint8_t  mon;   // 月（1~12）
    uint8_t  day;   // 日（1~30）
} DateTypeDef;

// 核心全局变量（修复显示缓冲区顺序）
volatile SystemState current_state = STATE_IDLE;
volatile DateTypeDef current_date = {2024, 10, 24}; // 初始：2024年10月24日
volatile DateTypeDef set_date = {2024, 10, 24};
// 8数码管显示缓冲区：[0]=年千位, [1]=年百位, [2]=年十位, [3]=年个位, [4]=月十位, [5]=月个位, [6]=日十位, [7]=日个位
volatile uint8_t display_buffer[8] = {0}; 
volatile uint8_t key_flag = 0;
volatile uint8_t uart_received_cmd = 0;
volatile uint8_t uart_cmd_ready = 0;
volatile uint8_t alarm_flag = 0;
volatile uint32_t ms_counter = 0;

// -------------------------- GPIO初始化 --------------------------
void GPIO_Init_All(void) {
    GPIO_InitTypeDef GPIO_InitStructure;
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB | RCC_APB2Periph_AFIO, ENABLE);
    GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable, ENABLE);

    // 数码管段选(PA0~7)：推挽输出
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3 | 
                                  GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    
    // LED(PA8/11/12/15)：初始熄灭
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8 | GPIO_Pin_11 | GPIO_Pin_12 | GPIO_Pin_15;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    GPIO_SetBits(GPIOA, GPIO_Pin_8 | GPIO_Pin_11 | GPIO_Pin_12 | GPIO_Pin_15);
    
    // UART1(TX=PA9/AF_PP, RX=PA10/浮空输入)
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    // 按键(PB0/1/4/5/上拉输入) + 数码管位选(PB12~14/推挽输出)
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_4 | GPIO_Pin_5;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12 | GPIO_Pin_13 | GPIO_Pin_14;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
}

// -------------------------- UART1初始化 --------------------------
void UART1_Init(void) {
    USART_InitTypeDef USART_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);

    USART_InitStructure.USART_BaudRate = 115200;
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;
    USART_InitStructure.USART_StopBits = USART_StopBits_1;
    USART_InitStructure.USART_Parity = USART_Parity_No;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
    USART_Init(USART1, &USART_InitStructure);

    USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);

    NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

    USART_Cmd(USART1, ENABLE);
}

// -------------------------- printf重定向 --------------------------
int fputc(int ch, FILE *f) {
    uint16_t timeout = 5000;
    while(USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET && timeout--);
    if(timeout > 0) USART_SendData(USART1, (uint8_t)ch);
    return ch;
}

// -------------------------- EXTI中断初始化 --------------------------
void EXTI_Keys_Init(void) {
    EXTI_InitTypeDef EXTI_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;

    // K1(PB0/下降沿)
    GPIO_EXTILineConfig(GPIO_PortSourceGPIOB, GPIO_PinSource0);
    EXTI_InitStructure.EXTI_Line = EXTI_Line0;
    EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;
    EXTI_Init(&EXTI_InitStructure);

    // K2(PB1/上升沿)
    GPIO_EXTILineConfig(GPIO_PortSourceGPIOB, GPIO_PinSource1);
    EXTI_InitStructure.EXTI_Line = EXTI_Line1;
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising;
    EXTI_Init(&EXTI_InitStructure);

    // K3(PB4/双边沿)
    GPIO_EXTILineConfig(GPIO_PortSourceGPIOB, GPIO_PinSource4);
    EXTI_InitStructure.EXTI_Line = EXTI_Line4;
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising_Falling;
    EXTI_Init(&EXTI_InitStructure);

    // K4(PB5/双边沿)
    GPIO_EXTILineConfig(GPIO_PortSourceGPIOB, GPIO_PinSource5);
    EXTI_InitStructure.EXTI_Line = EXTI_Line5;
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising_Falling;
    EXTI_Init(&EXTI_InitStructure);

    // NVIC配置
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    NVIC_InitStructure.NVIC_IRQChannel = EXTI0_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

    NVIC_InitStructure.NVIC_IRQChannel = EXTI1_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
    NVIC_Init(&NVIC_InitStructure);

    NVIC_InitStructure.NVIC_IRQChannel = EXTI4_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 3;
    NVIC_Init(&NVIC_InitStructure);

    NVIC_InitStructure.NVIC_IRQChannel = EXTI9_5_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 4;
    NVIC_Init(&NVIC_InitStructure);
}

// -------------------------- 定时器初始化 --------------------------
void TIM3_Init_1ms(void) {
    TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
    NVIC_InitTypeDef NVIC_InitStructure;

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);

    TIM_TimeBaseStructure.TIM_Prescaler = 7199;    // 72MHz/(7199+1)=10kHz
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseStructure.TIM_Period = 9;         // 10kHz/10=1kHz→1ms中断
    TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;
    TIM_TimeBaseStructure.TIM_RepetitionCounter = 0;
    TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure);

    TIM_ITConfig(TIM3, TIM_IT_Update, ENABLE);

    NVIC_InitStructure.NVIC_IRQChannel = TIM3_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

    TIM_Cmd(TIM3, ENABLE);
}

void TIM4_Init_1s(void) {
    TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
    NVIC_InitTypeDef NVIC_InitStructure;

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4, ENABLE);

    TIM_TimeBaseStructure.TIM_Prescaler = 7200 - 1;
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseStructure.TIM_Period = 10000 - 1;
    TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;
    TIM_TimeBaseStructure.TIM_RepetitionCounter = 0;
    TIM_TimeBaseInit(TIM4, &TIM_TimeBaseStructure);
    TIM_ClearFlag(TIM4, TIM_FLAG_Update);

    TIM_ITConfig(TIM4, TIM_IT_Update, ENABLE);

    NVIC_InitStructure.NVIC_IRQChannel = TIM4_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

    TIM_Cmd(TIM4, DISABLE);
}

// -------------------------- 日期处理与显示更新（核心修复） --------------------------
/**
 * 日期累加（1天）
 */
void Date_Add_OneDay(volatile DateTypeDef *date) {
    date->day++;
    // 日进位（31进制：>30则月+1，日=1）
    if(date->day > 30) {
        date->day = 1;
        date->mon++;
        // 月进位（13进制：>12则年+1，月=1）
        if(date->mon > 12) {
            date->mon = 1;
            date->year++;
        }
    }
}

/**
 * 显示缓冲区更新（年→月→日顺序）
 * 显示格式：8数码管从左到右 → [年千位][年百位][年十位][年个位] [月十位][月个位] [日十位][日个位]
 * 示例：2024年10月24日 → 2 0 2 4  1 0  2 4 → 显示"20241024"
 */
void Display_Update(void) {
    // 1. 年分解（左4位：[0]=千位, [1]=百位, [2]=十位, [3]=个位）
    if(current_state == STATE_SETTING_YEAR) {
        display_buffer[0] = (set_date.year / 1000) % 10;
        display_buffer[1] = (set_date.year / 100) % 10;
        display_buffer[2] = (set_date.year / 10) % 10;
        display_buffer[3] = set_date.year % 10;
    } else {
        display_buffer[0] = (current_date.year / 1000) % 10;
        display_buffer[1] = (current_date.year / 100) % 10;
        display_buffer[2] = (current_date.year / 10) % 10;
        display_buffer[3] = current_date.year % 10;
    }
    
    // 2. 月分解（中间2位：[4]=十位, [5]=个位）
    if(current_state == STATE_SETTING_MON) {
        display_buffer[4] = set_date.mon / 10;
        display_buffer[5] = set_date.mon % 10;
    } else {
        display_buffer[4] = current_date.mon / 10;
        display_buffer[5] = current_date.mon % 10;
    }
    
    // 3. 日分解（右2位：[6]=十位, [7]=个位）
    if(current_state == STATE_SETTING_DAY) {
        display_buffer[6] = set_date.day / 10;
        display_buffer[7] = set_date.day % 10;
    } else {
        display_buffer[6] = current_date.day / 10;
        display_buffer[7] = current_date.day % 10;
    }

    // 设置模式下当前项闪烁（熄灭对应位）
    static uint16_t flash_cnt = 0;
    flash_cnt++;
    if(flash_cnt >= 1000) flash_cnt = 0; // 1000ms闪烁一次
    if(flash_cnt < 500) {
        switch(current_state) {
            case STATE_SETTING_DAY:
                display_buffer[6] = 0xFF; display_buffer[7] = 0xFF; break; // 日闪烁（右2位）
            case STATE_SETTING_MON:
                display_buffer[4] = 0xFF; display_buffer[5] = 0xFF; break; // 月闪烁（中间2位）
            case STATE_SETTING_YEAR:
                display_buffer[0] = 0xFF; display_buffer[1] = 0xFF; display_buffer[2] = 0xFF; display_buffer[3] = 0xFF; break; // 年闪烁（左4位）
            default: break;
        }
    }
}

/**
 * 数码管扫描（位选与缓冲区严格对应）
 */
// 左到右位选映射（根据原理图：W8 W7 W6 W5 | W4 W3 W2 W1）
static const uint8_t digit_y_map[8] = {3,2,1,0,7,6,5,4};
static const uint8_t seg_to_buf_map[8] = {0,1,2,3,4,5,6,7};

void Display_Scan(void) {
    static uint8_t seg_idx = 0; // 扫描索引：0=最左一位，7=最右一位（与display_buffer一致）
    // 1. 关闭所有位选（防重影）
    GPIO_ResetBits(GPIOB, GPIO_Pin_12 | GPIO_Pin_13 | GPIO_Pin_14);
    // 2. 清除段选残留
    GPIO_ResetBits(GPIOA, 0x00FF);
    // 3. 输出当前段码（仅显示0~9，闪烁时熄灭）
    uint8_t buf_idx = seg_to_buf_map[seg_idx];
    if(display_buffer[buf_idx] <= 9) {
        GPIO_SetBits(GPIOA, seg_table[display_buffer[buf_idx]]);
    } else {
        GPIO_ResetBits(GPIOA, 0x00FF);
    }
    // 4. 选通当前数码管（74LS138：PB12=A, PB13=B, PB14=C → Y0~Y7）
    // 使用映射表确保左到右与display_buffer顺序一致
    uint8_t y = digit_y_map[seg_idx];
    uint16_t pins = 0;
    if (y & 0x01) pins |= GPIO_Pin_12; // A低位
    if (y & 0x02) pins |= GPIO_Pin_13; // B
    if (y & 0x04) pins |= GPIO_Pin_14; // C高位
    GPIO_SetBits(GPIOB, pins);
    // 5. 切换到下一位（从左到右扫描）
    seg_idx = (seg_idx + 1) % 8;
}

// -------------------------- 按键处理 --------------------------
void Key_Handler(void) {
    static uint32_t last_key_time[4] = {0};
    static uint8_t edge_count[4] = {0};

    // K1：切换设置项（日→月→年→退出）
    if(key_flag & KEY_K1) {
        if(ms_counter - last_key_time[0] > 20) {
            switch(current_state) {
                case STATE_IDLE: current_state = STATE_SETTING_DAY; printf("Enter setting: Day (right 2 digits)\r\n"); break;
                case STATE_SETTING_DAY: current_state = STATE_SETTING_MON; printf("Enter setting: Month (middle 2 digits)\r\n"); break;
                case STATE_SETTING_MON: current_state = STATE_SETTING_YEAR; printf("Enter setting: Year (left 4 digits)\r\n"); break;
                case STATE_SETTING_YEAR: current_state = STATE_IDLE; printf("Exit setting\r\n"); break;
            }
            last_key_time[0] = ms_counter;
        }
        key_flag &= ~KEY_K1;
    }

    // K2：开始计时（1秒=1天）
    if(key_flag & KEY_K2) {
        if(ms_counter - last_key_time[1] > 20) {
            if(current_state == STATE_IDLE) {
                current_date = (DateTypeDef){2024, 10, 24}; // 重置为初始日期
                alarm_flag = 0;
                TIM_SetCounter(TIM4, 0);
                TIM_Cmd(TIM4, ENABLE);
                printf("Start timing: current=%04d-%02d-%02d, target=%04d-%02d-%02d\r\n", 
                       current_date.year, current_date.mon, current_date.day,
                       set_date.year, set_date.mon, set_date.day);
            } else {
                printf("Cannot start while in setting mode\r\n");
            }
            last_key_time[1] = ms_counter;
        }
        key_flag &= ~KEY_K2;
    }

    // K3：当前设置项+1
    if(key_flag & KEY_K3) {
        if(ms_counter - last_key_time[2] > 10) {
            edge_count[2]++;
            if(edge_count[2] >= 2) {
                edge_count[2] = 0;
                switch(current_state) {
                    case STATE_SETTING_DAY:
                        set_date.day = (set_date.day >= 30) ? 1 : set_date.day + 1;
                        current_date.day = set_date.day;
                        printf("Set Day: %d (right 2 digits)\r\n", set_date.day);
                        break;
                    case STATE_SETTING_MON:
                        set_date.mon = (set_date.mon >= 12) ? 1 : set_date.mon + 1;
                        current_date.mon = set_date.mon;
                        printf("Set Month: %d (middle 2 digits)\r\n", set_date.mon);
                        break;
                    case STATE_SETTING_YEAR:
                        set_date.year++;
                        current_date.year = set_date.year;
                        printf("Set Year: %d (left 4 digits)\r\n", set_date.year);
                        break;
                    default: break;
                }
            }
            last_key_time[2] = ms_counter;
        }
        key_flag &= ~KEY_K3;
    }

    // K4：当前设置项-1
    if(key_flag & KEY_K4) {
        if(ms_counter - last_key_time[3] > 10) {
            edge_count[3]++;
            if(edge_count[3] >= 2) {
                edge_count[3] = 0;
                switch(current_state) {
                    case STATE_SETTING_DAY:
                        set_date.day = (set_date.day <= 1) ? 30 : set_date.day - 1;
                        current_date.day = set_date.day;
                        printf("Set Day: %d (right 2 digits)\r\n", set_date.day);
                        break;
                    case STATE_SETTING_MON:
                        set_date.mon = (set_date.mon <= 1) ? 12 : set_date.mon - 1;
                        current_date.mon = set_date.mon;
                        printf("Set Month: %d (middle 2 digits)\r\n", set_date.mon);
                        break;
                    case STATE_SETTING_YEAR:
                        set_date.year--;
                        current_date.year = set_date.year;
                        printf("Set Year: %d (left 4 digits)\r\n", set_date.year);
                        break;
                    default: break;
                }
            }
            last_key_time[3] = ms_counter;
        }
        key_flag &= ~KEY_K4;
    }
}

// -------------------------- 串口命令处理 --------------------------
void UART_Command_Handler(void) {
    if(uart_cmd_ready) {
        uart_cmd_ready = 0;
        switch(uart_received_cmd) {
            case 1: // 切换设置项（日→月→年→退出）
                switch(current_state) {
                    case STATE_IDLE: current_state = STATE_SETTING_DAY; printf("UART: enter Day setting (right 2 digits)\r\n"); break;
                    case STATE_SETTING_DAY: current_state = STATE_SETTING_MON; printf("UART: enter Month setting (middle 2 digits)\r\n"); break;
                    case STATE_SETTING_MON: current_state = STATE_SETTING_YEAR; printf("UART: enter Year setting (left 4 digits)\r\n"); break;
                    case STATE_SETTING_YEAR: current_state = STATE_IDLE; printf("UART: exit setting\r\n"); break;
                }
                break;
            case 2: // 开始计时
                if(current_state == STATE_IDLE) {
                    current_date = (DateTypeDef){2024, 10, 24};
                    alarm_flag = 0;
                    TIM_SetCounter(TIM4, 0);
                    TIM_Cmd(TIM4, ENABLE);
                    printf("UART: start timing, initial date=2024-10-24\r\n");
                } else {
                    printf("UART: cannot start while in setting mode\r\n");
                }
                break;
            case 3: // 当前项+1
                switch(current_state) {
                    case STATE_SETTING_DAY:
                        set_date.day = (set_date.day >= 30) ? 1 : set_date.day + 1;
                        current_date.day = set_date.day;
                        printf("UART: day+1=%d\r\n", set_date.day);
                        break;
                    case STATE_SETTING_MON:
                        set_date.mon = (set_date.mon >= 12) ? 1 : set_date.mon + 1;
                        current_date.mon = set_date.mon;
                        printf("UART: month+1=%d\r\n", set_date.mon);
                        break;
                    case STATE_SETTING_YEAR:
                        set_date.year++;
                        current_date.year = set_date.year;
                        printf("UART: year+1=%d\r\n", set_date.year);
                        break;
                    default: printf("UART: not in setting mode\r\n"); break;
                }
                break;
            case 4: // 当前项-1
                switch(current_state) {
                    case STATE_SETTING_DAY:
                        set_date.day = (set_date.day <= 1) ? 30 : set_date.day - 1;
                        current_date.day = set_date.day;
                        printf("UART: day-1=%d\r\n", set_date.day);
                        break;
                    case STATE_SETTING_MON:
                        set_date.mon = (set_date.mon <= 1) ? 12 : set_date.mon - 1;
                        current_date.mon = set_date.mon;
                        printf("UART: month-1=%d\r\n", set_date.mon);
                        break;
                    case STATE_SETTING_YEAR:
                        set_date.year--;
                        current_date.year = set_date.year;
                        printf("UART: year-1=%d\r\n", set_date.year);
                        break;
                    default: printf("UART: not in setting mode\r\n"); break;
                }
                break;
            case 5: // 发送设定日期
                printf("UART: set date: %04d-%02d-%02d (digits: %d%d%d%d %d%d %d%d)\r\n", 
                       set_date.year, set_date.mon, set_date.day,
                       (set_date.year/1000)%10, (set_date.year/100)%10, (set_date.year/10)%10, set_date.year%10,
                       set_date.mon/10, set_date.mon%10,
                       set_date.day/10, set_date.day%10);
                break;
            case 6: // 发送当前日期
                printf("UART: current date: %04d-%02d-%02d (digits: %d%d%d%d %d%d %d%d)\r\n", 
                       current_date.year, current_date.mon, current_date.day,
                       (current_date.year/1000)%10, (current_date.year/100)%10, (current_date.year/10)%10, current_date.year%10,
                       current_date.mon/10, current_date.mon%10,
                       current_date.day/10, current_date.day%10);
                break;
            default: printf("UART: invalid command (only 1-6)\r\n"); break;
        }
    }
}

// -------------------------- 中断服务函数 --------------------------
void EXTI0_IRQHandler(void) { if(EXTI_GetITStatus(EXTI_Line0)!=RESET) { key_flag|=KEY_K1; EXTI_ClearITPendingBit(EXTI_Line0); } }
void EXTI1_IRQHandler(void) { if(EXTI_GetITStatus(EXTI_Line1)!=RESET) { key_flag|=KEY_K2; EXTI_ClearITPendingBit(EXTI_Line1); } }
void EXTI4_IRQHandler(void) { if(EXTI_GetITStatus(EXTI_Line4)!=RESET) { key_flag|=KEY_K3; EXTI_ClearITPendingBit(EXTI_Line4); } }
void EXTI9_5_IRQHandler(void) { if(EXTI_GetITStatus(EXTI_Line5)!=RESET) { key_flag|=KEY_K4; EXTI_ClearITPendingBit(EXTI_Line5); } }

void USART1_IRQHandler(void) {
    if(USART_GetITStatus(USART1, USART_IT_RXNE)!=RESET) {
        uint8_t data = USART_ReceiveData(USART1);
        if(data >= '1' && data <= '6') {
            uart_received_cmd = data - '0';
            uart_cmd_ready = 1;
        }
        USART_ClearITPendingBit(USART1, USART_IT_RXNE);
    }
}

// TIM3中断：1ms更新ms_counter+显示
void TIM3_IRQHandler(void) {
    if(TIM_GetITStatus(TIM3, TIM_IT_Update)!=RESET) {
        ms_counter++;
        Display_Update(); // 更新缓冲区（年→月→日）
        Display_Scan();   // 扫描显示（左→右对应年→月→日）
        static uint16_t alarm_ms = 0;
        static uint8_t led_toggle = 0;
        if(alarm_flag) {
            alarm_ms++;
            if(alarm_ms >= 500) {
                alarm_ms = 0;
                led_toggle ^= 1;
                if(led_toggle) GPIO_ResetBits(GPIOA, GPIO_Pin_8 | GPIO_Pin_11 | GPIO_Pin_12 | GPIO_Pin_15);
                else GPIO_SetBits(GPIOA, GPIO_Pin_8 | GPIO_Pin_11 | GPIO_Pin_12 | GPIO_Pin_15);
            }
        }
        TIM_ClearITPendingBit(TIM3, TIM_IT_Update);
    }
}

// TIM4中断：1s日期累加+闹钟判断
void TIM4_IRQHandler(void) {
    if(TIM_GetITStatus(TIM4, TIM_IT_Update)!=RESET) {
        if(!alarm_flag) {
            Date_Add_OneDay(&current_date);
            // 判断是否到达设定日期
            if(current_date.year == set_date.year && 
               current_date.mon == set_date.mon && 
               current_date.day == set_date.day) {
                alarm_flag = 1;
                printf("Alarm triggered! current=%04d-%02d-%02d, target=%04d-%02d-%02d\r\n", 
                       current_date.year, current_date.mon, current_date.day,
                       set_date.year, set_date.mon, set_date.day);
            }
        } else {
            // 闹钟闪烁LED
            static uint8_t led_flag = 0;
            led_flag = !led_flag;
            if(led_flag) GPIO_ResetBits(GPIOA, GPIO_Pin_8 | GPIO_Pin_11 | GPIO_Pin_12 | GPIO_Pin_15);
            else GPIO_SetBits(GPIOA, GPIO_Pin_8 | GPIO_Pin_11 | GPIO_Pin_12 | GPIO_Pin_15);
        }
        TIM_ClearITPendingBit(TIM4, TIM_IT_Update);
    }
}

// -------------------------- 主函数 --------------------------
int main(void) {
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    GPIO_Init_All();
    UART1_Init();
    EXTI_Keys_Init();
    TIM3_Init_1ms();
    TIM4_Init_1s();

    // 系统启动提示
    printf("Date alarm system started!\r\n");
    printf("Display order (L->R): Y1k Y100 Y10 Y1 M10 M1 D10 D1\r\n");
    printf("Initial date: 2024-10-24 -> digits: 2 0 2 4 1 0 2 4\r\n");
    printf("Keys: K1=switch setting item, K2=start, K3=+1, K4=-1\r\n");
    printf("UART cmds: 1=switch, 2=start, 3=+1, 4=-1, 5=send set date, 6=send current date\r\n");

    while(1) {
        UART_Command_Handler();
        Key_Handler();

        // 闹钟模式：任意按键退出
        if(alarm_flag) {
            if(!GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0) || !GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_1) ||
               !GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_4) || !GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_5)) {
                GPIO_SetBits(GPIOA, GPIO_Pin_8 | GPIO_Pin_11 | GPIO_Pin_12 | GPIO_Pin_15);
                alarm_flag = 0;
                current_state = STATE_IDLE
                printf("Alarm closed, back to idle mode\r\n");
                TIM_Cmd(TIM4, DISABLE);
                current_date = (DateTypeDef){2024, 10, 24};
                set_date = (DateTypeDef){2024, 10, 24};
                
            }
        }
    }
}