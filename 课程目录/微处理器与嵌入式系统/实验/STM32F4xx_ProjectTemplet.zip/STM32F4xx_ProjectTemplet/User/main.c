
#include "stm32f4xx.h"
#include <stdbool.h>

int main(void) {
	
	while (true) {
		
	}
}
